#!/bin/bash

# 🚀 سكريبت إعداد بناء AI Agent Android - نسخة سريعة
# Quick Build Setup Script for AI Agent Android

echo "╔════════════════════════════════════════════════════════╗"
echo "║    🔧 AI Agent - Quick Build Setup                    ║"
echo "║    Android Project Compiler Fix                       ║"
echo "╚════════════════════════════════════════════════════════╝"
echo ""

# الألوان للطباعة
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# 1. التحقق من Java
echo -e "${YELLOW}[1/6]${NC} التحقق من Java Compiler..."
if ! command -v javac &> /dev/null; then
    echo -e "${RED}✗ Java Compiler غير مثبت${NC}"
    echo "على Ubuntu/Debian:"
    echo "  sudo apt-get install -y default-jdk"
    echo ""
    echo "على Mac:"
    echo "  brew install openjdk@17"
    echo ""
    exit 1
fi
JAVA_VERSION=$(javac -version 2>&1 | head -1)
echo -e "${GREEN}✓ Java متوفر: $JAVA_VERSION${NC}"
echo ""

# 2. التحقق من Gradle Wrapper
echo -e "${YELLOW}[2/6]${NC} التحقق من Gradle Wrapper..."
if [ ! -f "gradlew" ]; then
    echo -e "${RED}✗ gradlew غير موجود${NC}"
    exit 1
fi
chmod +x gradlew
echo -e "${GREEN}✓ Gradle Wrapper جاهز${NC}"
echo ""

# 3. إنشاء/تحديث local.properties
echo -e "${YELLOW}[3/6]${NC} تحديث local.properties..."
cat > local.properties << 'EOF'
# Android SDK Location Configuration
# Please update this path according to your system

# For Windows (example):
# sdk.dir=C:\\Users\\YourUsername\\AppData\\Local\\Android\\Sdk

# For macOS (example):
# sdk.dir=/Users/YourUsername/Library/Android/sdk

# For Linux (example):
# sdk.dir=/home/YourUsername/Android/Sdk

# Default path (please update):
sdk.dir=${HOME}/Android/Sdk
EOF
echo -e "${GREEN}✓ local.properties تم إنشاؤه${NC}"
echo "  ⚠️  تأكد من تحديث المسار إلى SDK الخاص بك"
echo ""

# 4. تحديث gradle.properties
echo -e "${YELLOW}[4/6]${NC} تحسين gradle.properties..."
if ! grep -q "android.disallowKotlinSourceSets=false" gradle.properties; then
    echo "android.disallowKotlinSourceSets=false" >> gradle.properties
fi
echo -e "${GREEN}✓ gradle.properties محسّن${NC}"
echo ""

# 5. تنظيف المشروع
echo -e "${YELLOW}[5/6]${NC} تنظيف المشروع..."
./gradlew clean
echo -e "${GREEN}✓ المشروع تم تنظيفه${NC}"
echo ""

# 6. بناء اختباري
echo -e "${YELLOW}[6/6]${NC} محاولة بناء اختبارية..."
echo "  (هذا قد يستغرق عدة دقائق في المرة الأولى)"
if ./gradlew build -x test --stacktrace 2>&1 | tail -20; then
    echo -e "${GREEN}✓ البناء نجح!${NC}"
else
    echo -e "${RED}✗ البناء فشل${NC}"
    echo "  تحقق من الخطأ أعلاه"
fi
echo ""

echo "╔════════════════════════════════════════════════════════╗"
echo "║            ✅ الإعداد اكتمل                             ║"
echo "╚════════════════════════════════════════════════════════╝"
echo ""
echo "الخطوات التالية:"
echo "1. تأكد من تحديث sdk.dir في local.properties"
echo "2. نفّذ: ./gradlew build"
echo "3. لبناء APK: ./gradlew assembleDebug"
echo ""
