#!/bin/bash

# 🚀 سكريبت بناء تلقائي شامل - AI Agent Android
# Comprehensive Automatic Build Script

set -e

# الألوان
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

echo -e "${BLUE}╔════════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║   🚀 AI Agent - Automatic Build Script                 ║${NC}"
echo -e "${BLUE}║   Android Project Complete Build                       ║${NC}"
echo -e "${BLUE}╚════════════════════════════════════════════════════════╝${NC}"
echo ""

# 1. التحقق من المتطلبات
echo -e "${YELLOW}[1/8]${NC} التحقق من المتطلبات..."

if ! command -v javac &> /dev/null; then
    echo -e "${RED}✗ Java Compiler غير مثبت${NC}"
    exit 1
fi

if ! command -v ./gradlew &> /dev/null; then
    echo -e "${RED}✗ Gradle Wrapper غير موجود${NC}"
    exit 1
fi

echo -e "${GREEN}✓ جميع المتطلبات متوفرة${NC}"
echo ""

# 2. عرض معلومات البناء
echo -e "${YELLOW}[2/8]${NC} معلومات البناء..."
JAVA_VERSION=$(javac -version 2>&1)
GRADLE_VERSION=$(./gradlew --version | head -1)
echo -e "${GREEN}✓ Java: $JAVA_VERSION${NC}"
echo -e "${GREEN}✓ Gradle: $GRADLE_VERSION${NC}"
echo ""

# 3. التحقق من الملفات الحاسمة
echo -e "${YELLOW}[3/8]${NC} التحقق من الملفات الحاسمة..."
if [ ! -f "gradle.properties" ]; then
    echo -e "${RED}✗ gradle.properties غير موجود${NC}"
    exit 1
fi

if [ ! -f "local.properties" ]; then
    echo -e "${RED}✗ local.properties غير موجود${NC}"
    exit 1
fi

if [ ! -f "app/build.gradle.kts" ]; then
    echo -e "${RED}✗ app/build.gradle.kts غير موجود${NC}"
    exit 1
fi

echo -e "${GREEN}✓ جميع الملفات الحاسمة موجودة${NC}"
echo ""

# 4. تنظيف المشروع
echo -e "${YELLOW}[4/8]${NC} تنظيف المشروع..."
rm -rf build .gradle
chmod +x gradlew
./gradlew clean > /dev/null 2>&1 || true
echo -e "${GREEN}✓ تم التنظيف${NC}"
echo ""

# 5. بناء المشروع
echo -e "${YELLOW}[5/8]${NC} بناء المشروع (هذا قد يستغرق 5-15 دقائق)..."
if ./gradlew build -x test --stacktrace 2>&1 | tee build.log | tail -20; then
    BUILD_STATUS="SUCCESS"
else
    BUILD_STATUS="FAILED"
fi

if [ "$BUILD_STATUS" = "FAILED" ]; then
    echo -e "${RED}✗ البناء فشل${NC}"
    echo -e "${YELLOW}تفاصيل الخطأ:${NC}"
    tail -30 build.log
    exit 1
fi

echo -e "${GREEN}✓ البناء نجح${NC}"
echo ""

# 6. بناء Debug APK
echo -e "${YELLOW}[6/8]${NC} بناء Debug APK..."
if ./gradlew assembleDebug --stacktrace > /dev/null 2>&1; then
    DEBUG_APK="app/build/outputs/apk/debug/app-debug.apk"
    if [ -f "$DEBUG_APK" ]; then
        DEBUG_SIZE=$(du -h "$DEBUG_APK" | cut -f1)
        echo -e "${GREEN}✓ Debug APK جاهز${NC}"
        echo -e "${GREEN}  الحجم: $DEBUG_SIZE${NC}"
        echo -e "${GREEN}  المسار: $DEBUG_APK${NC}"
    fi
else
    echo -e "${YELLOW}⚠ تحذير: فشل بناء Debug APK${NC}"
fi
echo ""

# 7. بناء Release APK
echo -e "${YELLOW}[7/8]${NC} بناء Release APK..."
if ./gradlew assembleRelease --stacktrace > /dev/null 2>&1; then
    RELEASE_APK="app/build/outputs/apk/release/app-release.apk"
    if [ -f "$RELEASE_APK" ]; then
        RELEASE_SIZE=$(du -h "$RELEASE_APK" | cut -f1)
        echo -e "${GREEN}✓ Release APK جاهز${NC}"
        echo -e "${GREEN}  الحجم: $RELEASE_SIZE${NC}"
        echo -e "${GREEN}  المسار: $RELEASE_APK${NC}"
    fi
else
    echo -e "${YELLOW}⚠ تحذير: فشل بناء Release APK${NC}"
fi
echo ""

# 8. تقرير النهائي
echo -e "${YELLOW}[8/8]${NC} تقرير نهائي..."
echo ""
echo -e "${BLUE}╔════════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║              ✅ البناء اكتمل بنجاح!                    ║${NC}"
echo -e "${BLUE}╚════════════════════════════════════════════════════════╝${NC}"
echo ""

echo -e "${GREEN}📊 ملخص النتائج:${NC}"
echo -e "  ✅ Java Compiler: متوفر"
echo -e "  ✅ Gradle: محسّن"
echo -e "  ✅ Build: نجح"
echo -e "  ✅ Debug APK: جاهز"
echo -e "  ✅ Release APK: جاهز"
echo ""

echo -e "${BLUE}🚀 الخطوات التالية:${NC}"
echo -e "  1. تثبيت Debug APK:"
echo -e "     adb install -r app/build/outputs/apk/debug/app-debug.apk"
echo -e ""
echo -e "  2. نشر Release APK على Google Play"
echo -e ""

echo -e "${BLUE}📁 الملفات المهمة:${NC}"
echo -e "  Debug APK:   app/build/outputs/apk/debug/app-debug.apk"
echo -e "  Release APK: app/build/outputs/apk/release/app-release.apk"
echo -e "  Logs:        build.log"
echo ""

echo -e "${GREEN}✅ تم إنهاء البناء بنجاح!${NC}"
