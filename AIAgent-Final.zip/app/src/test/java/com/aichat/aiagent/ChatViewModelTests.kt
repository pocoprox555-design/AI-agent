package com.aichat.aiagent

import com.aichat.aiagent.data.remote.api.ProviderFactory
import com.aichat.aiagent.data.repository.ChatRepository
import com.aichat.aiagent.domain.usecase.AutoRouter
import com.aichat.aiagent.domain.usecase.RateLimitHandler
import com.aichat.aiagent.ui.chat.ChatViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.setMain
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Before
import org.junit.Test
import org.mockito.Mock
import org.mockito.MockitoAnnotations

@OptIn(ExperimentalCoroutinesApi::class)
class ChatViewModelTests {

    private lateinit var viewModel: ChatViewModel

    @Mock
    private lateinit var chatRepository: ChatRepository

    @Mock
    private lateinit var autoRouter: AutoRouter

    @Mock
    private lateinit var providerFactory: ProviderFactory

    @Mock
    private lateinit var rateLimitHandler: RateLimitHandler

    private val testDispatcher = StandardTestDispatcher()

    @Before
    fun setUp() {
        MockitoAnnotations.openMocks(this)
        Dispatchers.setMain(testDispatcher)
        viewModel = ChatViewModel(chatRepository, autoRouter, providerFactory, rateLimitHandler)
    }

    @After
    fun tearDown() {
        Dispatchers.resetMain()
    }

    @Test
    fun testUpdateInput() {
        val testInput = "Hello AI"
        viewModel.updateInput(testInput)
        assertEquals(testInput, viewModel.state.value.inputText)
    }

    @Test
    fun testNewSessionKeepsStreamedTextEmpty() {
        viewModel.newSession()
        assertEquals("", viewModel.state.value.streamedText)
    }

    @Test
    fun testCancelStreamingResetsState() {
        viewModel.cancelStreaming()
        assertFalse(viewModel.state.value.isStreaming)
    }

    @Test
    fun testClearErrorSetsNull() {
        viewModel.clearError()
        assertNull(viewModel.state.value.error)
    }
}
