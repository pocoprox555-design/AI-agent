package com.aichat.aiagent

import com.aichat.aiagent.data.remote.api.ApiType
import com.aichat.aiagent.data.remote.api.PredefinedProviders
import com.aichat.aiagent.data.remote.api.ProviderConfig
import com.aichat.aiagent.data.remote.api.ProviderFactory
import com.aichat.aiagent.domain.model.ModelCategory
import com.aichat.aiagent.domain.usecase.AutoRouter
import com.aichat.aiagent.util.EncryptionUtil
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.mockito.Mock
import org.mockito.MockitoAnnotations

class AutoRouterTests {

    private lateinit var autoRouter: AutoRouter

    @Mock
    private lateinit var providerFactory: ProviderFactory

    @Mock
    private lateinit var encryptionUtil: EncryptionUtil

    @Before
    fun setUp() {
        MockitoAnnotations.openMocks(this)
        autoRouter = AutoRouter(providerFactory, encryptionUtil)
    }

    @Test
    fun testCodeDetection() {
        val message = "Write me a Kotlin function to parse JSON"
        val category = autoRouter.classifyIntentAdvanced(message)
        assertEquals(ModelCategory.CODE, category)
    }

    @Test
    fun testImageDetection() {
        val message = "Generate an image of a sunset"
        val category = autoRouter.classifyIntentAdvanced(message)
        assertEquals(ModelCategory.IMAGE, category)
    }

    @Test
    fun testAnalysisDetection() {
        val message = "What is machine learning?"
        val category = autoRouter.classifyIntentAdvanced(message)
        assertEquals(ModelCategory.ANALYSIS, category)
    }

    @Test
    fun testChatFallback() {
        val message = "Hello there"
        val category = autoRouter.classifyIntentAdvanced(message)
        assertEquals(ModelCategory.CHAT, category)
    }

    @Test
    fun testComplexityEstimation() {
        val simpleMessage = "Hi"
        val complexMessage = "Implement a distributed consensus algorithm with Byzantine fault tolerance"

        val simpleComplexity = autoRouter.estimateTaskComplexity(simpleMessage)
        val complexComplexity = autoRouter.estimateTaskComplexity(complexMessage)

        assertTrue("Complex message should have higher complexity than simple",
            simpleComplexity < complexComplexity)
    }

    @Test
    fun testTwentyProvidersDefined() {
        assertEquals(20, PredefinedProviders.all.size)
    }

    @Test
    fun testAllProvidersHaveValidUrls() {
        PredefinedProviders.all.forEach { config ->
            assertTrue("Provider ${config.id} should have non-blank base URL",
                config.baseUrl.isNotEmpty() || config.id == "custom")
            assertTrue("Provider ${config.id} should have at least one model",
                config.defaultModels.isNotEmpty())
        }
    }

    @Test
    fun testApiTypeCoverage() {
        val types = PredefinedProviders.all.map { it.apiType }.toSet()
        assertTrue("Should include OPENAI_COMPATIBLE", ApiType.OPENAI_COMPATIBLE in types)
        assertTrue("Should include GEMINI", ApiType.GEMINI in types)
        assertTrue("Should include ANTHROPIC", ApiType.ANTHROPIC in types)
        assertTrue("Should include COHERE", ApiType.COHERE in types)
    }
}
