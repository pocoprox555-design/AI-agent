package com.aichat.aiagent.data.local.datastore

import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

data class UserPreferences(
    val isDarkMode: Boolean = true,
    val isRtl: Boolean = true,
    val language: String = "ar",
    val defaultProviderId: String = "",
    val defaultModelId: String = "",
    val fontSizeScale: Int = 100,
    val isAutoRouteEnabled: Boolean = true,
    val apiKeyEncryptionEnabled: Boolean = true
)

@Singleton
class UserPreferencesRepository @Inject constructor(
    private val dataStore: DataStore<Preferences>
) {
    private object Keys {
        val IS_DARK_MODE = booleanPreferencesKey("is_dark_mode")
        val IS_RTL = booleanPreferencesKey("is_rtl")
        val LANGUAGE = stringPreferencesKey("language")
        val DEFAULT_PROVIDER_ID = stringPreferencesKey("default_provider_id")
        val DEFAULT_MODEL_ID = stringPreferencesKey("default_model_id")
        val FONT_SIZE_SCALE = intPreferencesKey("font_size_scale")
        val IS_AUTO_ROUTE_ENABLED = booleanPreferencesKey("is_auto_route_enabled")
        val API_KEY_ENCRYPTION_ENABLED = booleanPreferencesKey("api_key_encryption_enabled")
    }

    val preferences: Flow<UserPreferences> = dataStore.data.map { prefs ->
        UserPreferences(
            isDarkMode = prefs[Keys.IS_DARK_MODE] ?: true,
            isRtl = prefs[Keys.IS_RTL] ?: true,
            language = prefs[Keys.LANGUAGE] ?: "ar",
            defaultProviderId = prefs[Keys.DEFAULT_PROVIDER_ID] ?: "",
            defaultModelId = prefs[Keys.DEFAULT_MODEL_ID] ?: "",
            fontSizeScale = prefs[Keys.FONT_SIZE_SCALE] ?: 100,
            isAutoRouteEnabled = prefs[Keys.IS_AUTO_ROUTE_ENABLED] ?: true,
            apiKeyEncryptionEnabled = prefs[Keys.API_KEY_ENCRYPTION_ENABLED] ?: true
        )
    }

    suspend fun setDarkMode(enabled: Boolean) {
        dataStore.edit { it[Keys.IS_DARK_MODE] = enabled }
    }

    suspend fun setRtl(enabled: Boolean) {
        dataStore.edit { it[Keys.IS_RTL] = enabled }
    }

    suspend fun setLanguage(lang: String) {
        dataStore.edit { it[Keys.LANGUAGE] = lang }
    }

    suspend fun setDefaultProvider(providerId: String) {
        dataStore.edit { it[Keys.DEFAULT_PROVIDER_ID] = providerId }
    }

    suspend fun setDefaultModel(modelId: String) {
        dataStore.edit { it[Keys.DEFAULT_MODEL_ID] = modelId }
    }

    suspend fun setFontSizeScale(scale: Int) {
        dataStore.edit { it[Keys.FONT_SIZE_SCALE] = scale }
    }

    suspend fun setAutoRouteEnabled(enabled: Boolean) {
        dataStore.edit { it[Keys.IS_AUTO_ROUTE_ENABLED] = enabled }
    }
}
