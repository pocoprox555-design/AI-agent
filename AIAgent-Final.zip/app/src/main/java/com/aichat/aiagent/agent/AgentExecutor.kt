package com.aichat.aiagent.agent

import com.aichat.aiagent.data.repository.ChatRepository
import com.aichat.aiagent.data.repository.ProviderRepository
import com.aichat.aiagent.domain.model.ChatMessage
import com.aichat.aiagent.domain.model.MessageRole
import com.aichat.aiagent.domain.usecase.AutoRouter
import com.aichat.aiagent.util.TokenCounter
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class AgentExecutor @Inject constructor(
    private val chatRepository: ChatRepository,
    private val autoRouter: AutoRouter,
    private val providerRepository: ProviderRepository,
    private val fileProcessor: FileProcessor
) {
    suspend fun executeTask(
        sessionId: Long,
        instruction: String,
        fileContent: FileContent? = null
    ): Result<ChatMessage> {
        var prompt = instruction

        if (fileContent != null) {
            prompt = """
                File: ${fileContent.fileName}
                Type: ${fileContent.mimeType}
                
                Content:
                ```
                ${fileContent.content.take(8000)}
                ```
                
                Instruction: $instruction
                
                Analyze the file and provide your response.
            """.trimIndent()
        }

        val enabledProviders = providerRepository.getAllPredefinedConfigs()
        val routing = autoRouter.route(prompt, enabledProviders)

        return chatRepository.sendMessage(
            sessionId = sessionId,
            content = prompt,
            providerId = routing.providerId,
            modelId = routing.modelId
        )
    }
}
