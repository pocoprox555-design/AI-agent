package com.aichat.aiagent.ui.providers

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.aichat.aiagent.data.local.database.entity.ProviderConfigEntity
import com.aichat.aiagent.data.remote.api.PredefinedProviders
import com.aichat.aiagent.data.remote.api.ProviderConfig
import com.aichat.aiagent.data.repository.ProviderRepository
import com.aichat.aiagent.data.repository.ValidationResult
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

data class ProvidersUiState(
    val providers: List<ProviderItem> = emptyList(),
    val isLoading: Boolean = false,
    val validatingProvider: String? = null,
    val apiKeyInputs: Map<String, String> = emptyMap(),
    val message: String? = null
)

data class ProviderItem(
    val config: ProviderConfig,
    val entity: ProviderConfigEntity?,
    val isEnabled: Boolean,
    val models: List<String>,
    val hasKey: Boolean,
    val isValidating: Boolean = false,
    val validationMessage: String? = null
)

@HiltViewModel
class ProvidersViewModel @Inject constructor(
    private val repository: ProviderRepository
) : ViewModel() {

    private val _state = MutableStateFlow(ProvidersUiState())
    val state: StateFlow<ProvidersUiState> = _state.asStateFlow()

    init {
        loadProviders()
    }

    private fun loadProviders() {
        viewModelScope.launch {
            _state.value = _state.value.copy(isLoading = true)
            repository.initializeDefaultProviders()
            repository.observeAllProviders().collect { entities ->
                val configs = repository.getAllPredefinedConfigs()
                val items = configs.map { config ->
                    val entity = entities.find { it.id == config.id }
                    ProviderItem(
                        config = config,
                        entity = entity,
                        isEnabled = entity?.isEnabled ?: false,
                        models = parseModels(entity?.models ?: ""),
                        hasKey = entity?.apiKey?.isNotEmpty() ?: repository.getApiKey(config.id).isNotEmpty(),
                        validationMessage = if (entity?.apiKey?.isNotEmpty() == true) "Key saved" else null
                    )
                }
                _state.value = _state.value.copy(
                    providers = items,
                    isLoading = false
                )
            }
        }
    }

    fun updateApiKeyInput(providerId: String, key: String) {
        val inputs = _state.value.apiKeyInputs.toMutableMap()
        inputs[providerId] = key
        _state.value = _state.value.copy(apiKeyInputs = inputs)
    }

    fun saveAndValidateApiKey(providerId: String) {
        val apiKey = _state.value.apiKeyInputs[providerId] ?: ""
        if (apiKey.isBlank()) return

        viewModelScope.launch {
            _state.value = _state.value.copy(validatingProvider = providerId)
            repository.saveApiKey(providerId, apiKey)
            val result = repository.validateApiKey(providerId)
            val items = _state.value.providers.map {
                if (it.config.id == providerId) {
                    it.copy(
                        hasKey = result.success,
                        validationMessage = result.message,
                        isValidating = false
                    )
                } else it
            }
            _state.value = _state.value.copy(
                providers = items,
                validatingProvider = null,
                message = if (result.success) "✅ ${result.message}" else "❌ ${result.message}"
            )
            if (result.success) {
                fetchModels(providerId)
            }
            val inputs = _state.value.apiKeyInputs.toMutableMap()
            inputs.remove(providerId)
            _state.value = _state.value.copy(apiKeyInputs = inputs)
        }
    }

    fun fetchModels(providerId: String) {
        viewModelScope.launch {
            val models = repository.fetchModels(providerId)
            val items = _state.value.providers.map {
                if (it.config.id == providerId) it.copy(models = models) else it
            }
            _state.value = _state.value.copy(providers = items)
        }
    }

    fun toggleProvider(providerId: String, enabled: Boolean) {
        viewModelScope.launch {
            repository.setProviderEnabled(providerId, enabled)
        }
    }

    fun clearMessage() {
        _state.value = _state.value.copy(message = null)
    }

    private fun parseModels(models: String): List<String> {
        return if (models.isBlank()) emptyList() else models.split(",").filter { it.isNotBlank() }
    }
}
