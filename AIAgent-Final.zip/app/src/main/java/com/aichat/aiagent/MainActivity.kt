package com.aichat.aiagent

import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Help
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.fragment.app.FragmentActivity
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.aichat.aiagent.ui.auth.AuthScreen
import com.aichat.aiagent.ui.auth.AuthViewModel
import com.aichat.aiagent.ui.components.ParticlesBackground
import com.aichat.aiagent.ui.navigation.AppNavigation
import com.aichat.aiagent.ui.navigation.Screen
import com.aichat.aiagent.ui.settings.SettingsViewModel
import com.aichat.aiagent.ui.theme.AIAgentTheme
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : FragmentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val settingsViewModel: SettingsViewModel = hiltViewModel()
            val prefs by settingsViewModel.preferences.collectAsState()
            val layoutDirection = if (prefs?.isRtl == true) LayoutDirection.Rtl else LayoutDirection.Ltr

            AIAgentTheme(darkTheme = prefs?.isDarkMode ?: true, dynamicColor = false) {
                androidx.compose.runtime.CompositionLocalProvider(
                    LocalLayoutDirection provides layoutDirection
                ) {
                    val authViewModel: AuthViewModel = hiltViewModel()
                    val authState by authViewModel.state.collectAsState()

                    if (authState.isAuthenticated) {
                        val navController = rememberNavController()
                        val navBackStackEntry by navController.currentBackStackEntryAsState()
                        val currentRoute = navBackStackEntry?.destination?.route

                        Scaffold(
                            modifier = Modifier.fillMaxSize(),
                            bottomBar = {
                                NavigationBar(
                                    containerColor = MaterialTheme.colorScheme.surface,
                                    contentColor = MaterialTheme.colorScheme.onSurface
                                ) {
                                    Screen.bottomNavItems.forEach { screen ->
                                        val selected = currentRoute == screen.route
                                        NavigationBarItem(
                                            selected = selected,
                                            onClick = {
                                                if (currentRoute != screen.route) {
                                                    navController.navigate(screen.route) {
                                                        popUpTo(navController.graph.startDestinationId) {
                                                            saveState = true
                                                        }
                                                        launchSingleTop = true
                                                        restoreState = true
                                                    }
                                                }
                                            },
                                            icon = {
                                                val icon = if (selected) {
                                                    screen.selectedIcon ?: screen.unselectedIcon
                                                } else {
                                                    screen.unselectedIcon ?: screen.selectedIcon
                                                } ?: Icons.Default.Help

                                                Icon(
                                                    imageVector = icon,
                                                    contentDescription = screen.route
                                                )
                                            },
                                            label = { Text(screen.route.replaceFirstChar { it.uppercase() }) },
                                            colors = NavigationBarItemDefaults.colors(
                                                selectedIconColor = MaterialTheme.colorScheme.primary,
                                                selectedTextColor = MaterialTheme.colorScheme.primary,
                                                unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                                unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                                indicatorColor = MaterialTheme.colorScheme.primaryContainer
                                            )
                                        )
                                    }
                                }
                            }
                        ) { innerPadding ->
                            Box(modifier = Modifier.fillMaxSize().padding(innerPadding)) {
                                // 2050 futuristic animated particles background
                                ParticlesBackground(
                                    modifier = Modifier.fillMaxSize(),
                                    particleCount = 35
                                )
                                AppNavigation(
                                    navController = navController,
                                    modifier = Modifier.fillMaxSize()
                                )
                            }
                        }
                    } else {
                        Box(modifier = Modifier.fillMaxSize()) {
                            ParticlesBackground(
                                modifier = Modifier.fillMaxSize(),
                                particleCount = 40
                            )
                            AuthScreen(
                                state = authState,
                                onSetPin = { pin -> authViewModel.setPin(pin) },
                                onVerifyPin = { pin -> authViewModel.verifyPin(pin) },
                                onBiometricSuccess = { authViewModel.onBiometricSuccess() },
                                onSkip = { authViewModel.skipAuth() },
                                onBiometricAvailable = { authViewModel.setBiometricAvailable(it) }
                            )
                        }
                    }
                }
            }
        }
    }
}
