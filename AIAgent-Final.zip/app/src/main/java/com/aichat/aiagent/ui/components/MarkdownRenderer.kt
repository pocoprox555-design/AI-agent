package com.aichat.aiagent.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aichat.aiagent.ui.theme.CyanNeon
import com.aichat.aiagent.ui.theme.MagentaNeon
import com.aichat.aiagent.ui.theme.SuccessGreen

@Composable
fun MarkdownText(
    markdown: String,
    modifier: Modifier = Modifier
) {
    val blocks = remember(markdown) { parseMarkdown(markdown) }

    Column(modifier = modifier.fillMaxWidth()) {
        blocks.forEach { block ->
            when (block) {
                is MarkdownBlock.Heading -> Text(
                    text = block.text,
                    style = when (block.level) {
                        1 -> MaterialTheme.typography.headlineMedium
                        2 -> MaterialTheme.typography.titleLarge
                        else -> MaterialTheme.typography.titleMedium
                    },
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(vertical = 4.dp)
                )
                is MarkdownBlock.CodeBlock -> CodeBlockView(block)
                is MarkdownBlock.InlineText -> Text(
                    text = parseInlineMarkdown(block.text),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.padding(vertical = 2.dp)
                )
                is MarkdownBlock.BulletItem -> Text(
                    text = "  \u2022  ${block.text}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.padding(vertical = 1.dp)
                )
                is MarkdownBlock.Divider -> HorizontalDivider(
                    modifier = Modifier.padding(vertical = 8.dp),
                    color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f)
                )
            }
        }
    }
}

@Composable
private fun CodeBlockView(block: MarkdownBlock.CodeBlock) {
    val scrollState = rememberScrollState()
    val highlighted: AnnotatedString = remember(block.code, block.language) {
        highlightSyntax(block.code, block.language)
    }
    Column {
        if (block.language.isNotEmpty()) {
            Text(
                text = block.language,
                style = MaterialTheme.typography.labelSmall,
                color = CyanNeon.copy(alpha = 0.7f),
                modifier = Modifier.padding(start = 4.dp, bottom = 2.dp)
            )
        }
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                .horizontalScroll(scrollState)
                .padding(12.dp)
        ) {
            Text(
                text = highlighted,
                style = MaterialTheme.typography.bodySmall.copy(
                    fontFamily = FontFamily.Monospace,
                    fontSize = 12.sp
                ),
                color = Color(0xFFE6E6E6)
            )
        }
    }
}

private sealed class MarkdownBlock {
    data class Heading(val text: String, val level: Int) : MarkdownBlock()
    data class CodeBlock(val code: String, val language: String = "") : MarkdownBlock()
    data class InlineText(val text: String) : MarkdownBlock()
    data class BulletItem(val text: String) : MarkdownBlock()
    data object Divider : MarkdownBlock()
}

private fun parseMarkdown(md: String): List<MarkdownBlock> {
    val blocks = mutableListOf<MarkdownBlock>()
    val lines = md.split("\n")
    var i = 0
    while (i < lines.size) {
        val line = lines[i]
        when {
            line.startsWith("###") -> { blocks.add(MarkdownBlock.Heading(line.drop(3).trim(), 3)); i++ }
            line.startsWith("##") -> { blocks.add(MarkdownBlock.Heading(line.drop(2).trim(), 2)); i++ }
            line.startsWith("#") -> { blocks.add(MarkdownBlock.Heading(line.drop(1).trim(), 1)); i++ }
            line.startsWith("```") -> {
                val lang = line.drop(3).trim()
                val codeLines = mutableListOf<String>()
                i++
                while (i < lines.size && !lines[i].startsWith("```")) { codeLines.add(lines[i]); i++ }
                blocks.add(MarkdownBlock.CodeBlock(codeLines.joinToString("\n"), lang))
                i++
            }
            line.startsWith("---") || line.startsWith("***") -> { blocks.add(MarkdownBlock.Divider); i++ }
            line.startsWith("- ") || line.startsWith("* ") -> { blocks.add(MarkdownBlock.BulletItem(line.drop(2).trim())); i++ }
            line.isBlank() -> i++
            else -> { blocks.add(MarkdownBlock.InlineText(line)); i++ }
        }
    }
    return blocks
}

private fun parseInlineMarkdown(text: String): AnnotatedString {
    return buildAnnotatedString {
        var remaining = text
        while (remaining.isNotEmpty()) {
            when {
                remaining.startsWith("**") -> {
                    val end = remaining.indexOf("**", 2)
                    if (end > 2) {
                        withStyle(SpanStyle(fontWeight = FontWeight.Bold)) { append(remaining.substring(2, end)) }
                        remaining = remaining.substring(end + 2)
                    } else { append(remaining); remaining = "" }
                }
                remaining.startsWith("`") -> {
                    val end = remaining.indexOf("`", 1)
                    if (end > 1) {
                        withStyle(SpanStyle(fontFamily = FontFamily.Monospace, color = MagentaNeon, fontSize = 13.sp)) {
                            append(remaining.substring(1, end))
                        }
                        remaining = remaining.substring(end + 1)
                    } else { append(remaining); remaining = "" }
                }
                remaining.startsWith("*") && !remaining.startsWith("**") -> {
                    val end = remaining.indexOf("*", 1)
                    if (end > 1) {
                        withStyle(SpanStyle(fontStyle = FontStyle.Italic)) {
                            append(remaining.substring(1, end))
                        }
                        remaining = remaining.substring(end + 1)
                    } else { append(remaining); remaining = "" }
                }
                else -> {
                    val next = listOfNotNull(
                        remaining.indexOf("**").takeIf { it >= 0 },
                        remaining.indexOf("`").takeIf { it >= 0 },
                        remaining.indexOf("*").takeIf { it >= 0 }
                    ).filter { it >= 0 }.minOrNull() ?: remaining.length
                    append(remaining.take(next))
                    remaining = remaining.substring(next)
                }
            }
        }
    }
}

private fun highlightSyntax(code: String, language: String): AnnotatedString {
    val lang = language.lowercase()
    return when {
        lang in listOf("kotlin", "kt", "java") -> highlightGeneric(code, kotlinKeywords)
        lang in listOf("python", "py") -> highlightGeneric(code, pythonKeywords)
        lang in listOf("javascript", "js", "typescript", "ts") -> highlightGeneric(code, jsKeywords)
        lang in listOf("xml", "html", "json") -> buildAnnotatedString { append(code) }
        lang == "sql" -> highlightGeneric(code, sqlKeywords)
        else -> buildAnnotatedString { append(code) }
    }
}

private val kotlinKeywords = setOf("val", "var", "fun", "class", "object", "if", "else", "when", "for",
    "while", "return", "import", "package", "private", "public", "protected", "internal", "abstract",
    "open", "override", "data", "sealed", "enum", "interface", "companion", "init", "constructor",
    "suspend", "inline", "infix", "operator", "tailrec", "as", "is", "in", "try", "catch", "finally",
    "throw", "null", "true", "false", "super", "this", "typealias", "expect", "actual", "value")

private val pythonKeywords = setOf("def", "class", "if", "elif", "else", "for", "while", "return",
    "import", "from", "as", "try", "except", "finally", "raise", "with", "yield", "lambda", "pass",
    "break", "continue", "and", "or", "not", "in", "is", "None", "True", "False", "self", "async",
    "await", "print", "range", "len", "str", "int", "float", "list", "dict", "set", "tuple")

private val jsKeywords = setOf("function", "const", "let", "var", "if", "else", "for", "while",
    "return", "class", "import", "export", "from", "async", "await", "try", "catch", "finally",
    "throw", "new", "this", "null", "undefined", "true", "false", "typeof", "instanceof", "of",
    "in", "switch", "case", "break", "continue", "default", "extends", "super", "static", "get", "set")

private val sqlKeywords = setOf("SELECT", "FROM", "WHERE", "INSERT", "INTO", "VALUES", "UPDATE",
    "SET", "DELETE", "CREATE", "TABLE", "ALTER", "DROP", "INDEX", "JOIN", "LEFT", "RIGHT", "INNER",
    "OUTER", "ON", "AND", "OR", "NOT", "IN", "LIKE", "BETWEEN", "ORDER", "BY", "GROUP", "HAVING",
    "LIMIT", "OFFSET", "AS", "DISTINCT", "COUNT", "SUM", "AVG", "MAX", "MIN", "UNION", "ALL",
    "EXISTS", "CASE", "WHEN", "THEN", "ELSE", "END", "NULL", "IS", "ASC", "DESC")

private val keywordColor = MagentaNeon
private val stringColor = SuccessGreen
private val commentColor = Color(0xFF6A9955)
private val numberColor = Color(0xFFB5CEA8)
private val annotationColor = Color(0xFFC586C0)

private data class ColoredSpan(val start: Int, val end: Int, val color: Color)

private fun highlightGeneric(code: String, keywords: Set<String>): AnnotatedString {
    val spans = mutableListOf<ColoredSpan>()
    var i = 0
    while (i < code.length) {
        when {
            code.startsWith("//", i) -> {
                val end = code.indexOf('\n', i).let { if (it == -1) code.length else it }
                spans.add(ColoredSpan(i, end, commentColor))
                i = end
            }
            code.startsWith("/*", i) -> {
                val end = code.indexOf("*/", i + 2).let { if (it == -1) code.length else it + 2 }
                spans.add(ColoredSpan(i, end, commentColor))
                i = end
            }
            code[i] == '"' || code[i] == '\'' -> {
                val quote = code[i]
                val start = i
                i++
                while (i < code.length && code[i] != quote) { if (code[i] == '\\') i++; i++ }
                if (i < code.length) i++
                spans.add(ColoredSpan(start, i, stringColor))
            }
            code[i].isDigit() && (i == 0 || !code[i - 1].isLetterOrDigit()) -> {
                val start = i
                while (i < code.length && (code[i].isDigit() || code[i] == '.' || code[i] == 'f' || code[i] == 'L')) i++
                spans.add(ColoredSpan(start, i, numberColor))
            }
            code[i] == '@' -> {
                val start = i
                i++
                while (i < code.length && (code[i].isLetterOrDigit() || code[i] == '_')) i++
                spans.add(ColoredSpan(start, i, annotationColor))
            }
            code[i].isLetter() || code[i] == '_' -> {
                val start = i
                while (i < code.length && (code[i].isLetterOrDigit() || code[i] == '_')) i++
                val word = code.substring(start, i)
                if (word in keywords) {
                    spans.add(ColoredSpan(start, i, keywordColor))
                }
            }
            else -> i++
        }
    }

    return buildAnnotatedString {
        val sorted = spans.sortedBy { it.start }
        var pos = 0
        for (span in sorted) {
            if (span.start > pos) {
                append(code.substring(pos, span.start))
            }
            withStyle(SpanStyle(color = span.color)) {
                append(code.substring(span.start, span.end))
            }
            pos = span.end
        }
        if (pos < code.length) {
            append(code.substring(pos))
        }
    }
}
