package com.aichat.aiagent.data.remote.dto

import com.google.gson.annotations.SerializedName

data class ChatCompletionRequest(
    @SerializedName("model") val model: String,
    @SerializedName("messages") val messages: List<MessageDto>,
    @SerializedName("temperature") val temperature: Double = 0.7,
    @SerializedName("max_tokens") val maxTokens: Int = 2048,
    @SerializedName("stream") val stream: Boolean = false
)

data class MessageDto(
    @SerializedName("role") val role: String,
    @SerializedName("content") val content: String
)

data class ChatCompletionResponse(
    @SerializedName("id") val id: String? = null,
    @SerializedName("object") val `object`: String? = null,
    @SerializedName("created") val created: Long? = null,
    @SerializedName("model") val model: String? = null,
    @SerializedName("choices") val choices: List<ChoiceDto>? = null,
    @SerializedName("usage") val usage: UsageDto? = null,
    @SerializedName("error") val error: ErrorDto? = null
)

data class ChoiceDto(
    @SerializedName("index") val index: Int? = null,
    @SerializedName("delta") val delta: DeltaDto? = null,
    @SerializedName("message") val message: MessageDto? = null,
    @SerializedName("finish_reason") val finishReason: String? = null
)

data class DeltaDto(
    @SerializedName("role") val role: String? = null,
    @SerializedName("content") val content: String? = null
)

data class UsageDto(
    @SerializedName("prompt_tokens") val promptTokens: Int? = null,
    @SerializedName("completion_tokens") val completionTokens: Int? = null,
    @SerializedName("total_tokens") val totalTokens: Int? = null
)

data class ErrorDto(
    @SerializedName("message") val message: String? = null,
    @SerializedName("type") val type: String? = null,
    @SerializedName("code") val code: String? = null
)
