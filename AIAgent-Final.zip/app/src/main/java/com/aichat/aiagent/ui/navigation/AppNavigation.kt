package com.aichat.aiagent.ui.navigation

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.aichat.aiagent.ui.chat.ChatScreen
import com.aichat.aiagent.ui.providers.ProvidersScreen
import com.aichat.aiagent.ui.tasks.TasksScreen
import com.aichat.aiagent.ui.projects.ProjectsScreen
import com.aichat.aiagent.ui.settings.SettingsScreen

@Composable
fun AppNavigation(navController: NavHostController, modifier: Modifier = Modifier) {
    NavHost(
        navController = navController,
        startDestination = Screen.Chat.route,
        modifier = modifier
    ) {
        composable(Screen.Chat.route) {
            ChatScreen()
        }
        composable(Screen.Providers.route) {
            ProvidersScreen()
        }
        composable(Screen.Tasks.route) {
            TasksScreen()
        }
        composable(Screen.Projects.route) {
            ProjectsScreen()
        }
        composable(Screen.Settings.route) {
            SettingsScreen()
        }
    }
}
