package com.aichat.aiagent.domain.model

data class Provider(
    val id: String,
    val name: String,
    val baseUrl: String,
    val apiKey: String = "",
    val isEnabled: Boolean = true,
    val priority: Int = 0,
    val models: List<AiModel> = emptyList(),
    val authType: AuthType = AuthType.HEADER_BEARER
)

enum class AuthType {
    HEADER_BEARER,
    HEADER_API_KEY,
    QUERY_PARAM,
    X_API_KEY
}
