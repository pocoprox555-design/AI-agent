package com.aichat.aiagent.ui.theme

import androidx.compose.ui.graphics.Color

val CyanNeon = Color(0xFF00D4FF)
val CyanNeonDim = Color(0xFF00A8CC)
val MagentaNeon = Color(0xFFFF00FF)
val MagentaNeonDim = Color(0xFFCC00CC)
val DeepSpace = Color(0xFF0A0E27)
val DarkBlueSurface = Color(0xFF151B3D)
val DarkCard = Color(0xFF1E2550)
val DarkSurfaceVariant = Color(0xFF2A3260)
val DarkOnSurface = Color(0xFFE8EAF6)
val DarkOnSurfaceVariant = Color(0xFFB0B8D1)

val LightBackground = Color(0xFFF5F7FA)
val LightSurface = Color(0xFFFFFFFF)
val LightPrimary = Color(0xFF0066CC)
val LightSecondary = Color(0xFFFF6600)
val LightOnSurface = Color(0xFF1C1B1F)
val LightOnSurfaceVariant = Color(0xFF49454F)
val LightCard = Color(0xFFF0F4FF)

val ErrorRed = Color(0xFFCF6679)
val SuccessGreen = Color(0xFF4CAF50)
val WarningOrange = Color(0xFFFF9800)
val GlassOverlay = Color(0x33FFFFFF)
val GlassBorder = Color(0x4DFFFFFF)
