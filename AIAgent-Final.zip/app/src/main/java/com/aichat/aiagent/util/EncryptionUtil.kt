package com.aichat.aiagent.util

import android.content.Context
import android.content.SharedPreferences
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import dagger.hilt.android.qualifiers.ApplicationContext
import java.security.KeyStore
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class EncryptionUtil @Inject constructor(
    @ApplicationContext context: Context
) {
    private val masterKey = MasterKey.Builder(context)
        .setKeyGenParameterSpec(
            KeyGenParameterSpec.Builder(
                MasterKey.DEFAULT_MASTER_KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            )
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        .build()

    private val encryptedPrefs: SharedPreferences = EncryptedSharedPreferences.create(
        context,
        "ai_agent_secure_prefs",
        masterKey,
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    // Android Keystore aliases for app secrets
    private val keystore = KeyStore.getInstance(ANDROID_KEYSTORE).apply { load(null) }
    private val keyStoreAlias = "ai_agent_db_key_alias"

    /**
     * Returns or generates a 32-byte SQLCipher passphrase.
     * The passphrase itself is generated using SecureRandom and stored encrypted
     * inside EncryptedSharedPreferences (which itself uses Android Keystore).
     * Reuses the same passphrase across launches; rotates only if explicitly cleared.
     */
    fun getOrCreateDatabasePassphrase(): ByteArray {
        val existing = encryptedPrefs.getString(KEY_DB_PASSPHRASE, null)
        if (existing != null) {
            return existing.decodeBase64Compat()
        }
        val bytes = ByteArray(32)
        SecureRandom().nextBytes(bytes)
        encryptedPrefs.edit().putString(KEY_DB_PASSPHRASE, bytes.encodeBase64Compat()).apply()
        return bytes
    }

    fun saveApiKey(providerId: String, apiKey: String) {
        encryptedPrefs.edit().putString("api_key_$providerId", apiKey).apply()
    }

    fun getApiKey(providerId: String): String {
        return encryptedPrefs.getString("api_key_$providerId", "") ?: ""
    }

    fun hasApiKey(providerId: String): Boolean {
        return getApiKey(providerId).isNotEmpty()
    }

    fun deleteApiKey(providerId: String) {
        encryptedPrefs.edit().remove("api_key_$providerId").apply()
    }

    fun saveString(key: String, value: String) {
        encryptedPrefs.edit().putString(key, value).apply()
    }

    fun getString(key: String, default: String = ""): String {
        return encryptedPrefs.getString(key, default) ?: default
    }

    /**
     * Symmetric encrypt/decrypt helper using Android Keystore.
     * Useful for protecting other sensitive runtime secrets beyond API keys.
     */
    fun encryptWithKeystore(plaintext: ByteArray): ByteArray {
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.ENCRYPT_MODE, getOrCreateAesKey())
        val iv = cipher.iv
        val encrypted = cipher.doFinal(plaintext)
        // Prepend IV (12 bytes) to ciphertext
        return iv + encrypted
    }

    fun decryptWithKeystore(ciphertext: ByteArray): ByteArray {
        require(ciphertext.size > IV_LENGTH) { "Invalid ciphertext" }
        val iv = ciphertext.copyOfRange(0, IV_LENGTH)
        val data = ciphertext.copyOfRange(IV_LENGTH, ciphertext.size)
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.DECRYPT_MODE, getOrCreateAesKey(), GCMParameterSpec(GCM_TAG_LENGTH, iv))
        return cipher.doFinal(data)
    }

    private fun getOrCreateAesKey(): SecretKey {
        keystore.getEntry(keyStoreAlias, null)?.let {
            return (it as KeyStore.SecretKeyEntry).secretKey
        }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, ANDROID_KEYSTORE)
        generator.init(
            KeyGenParameterSpec.Builder(
                keyStoreAlias,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            )
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        return generator.generateKey()
    }

    private fun ByteArray.encodeBase64Compat(): String =
        android.util.Base64.encodeToString(this, android.util.Base64.NO_WRAP)

    private fun String.decodeBase64Compat(): ByteArray =
        android.util.Base64.decode(this, android.util.Base64.NO_WRAP)

    companion object {
        private const val ANDROID_KEYSTORE = "AndroidKeyStore"
        private const val TRANSFORMATION = "AES/GCM/NoPadding"
        private const val GCM_TAG_LENGTH = 128
        private const val IV_LENGTH = 12
        private const val KEY_DB_PASSPHRASE = "sqlcipher_passphrase_v1"
    }
}
