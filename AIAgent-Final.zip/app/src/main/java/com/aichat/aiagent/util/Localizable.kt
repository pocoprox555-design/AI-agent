package com.aichat.aiagent.util

import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

/**
 * Helper that converts a string key into a localized string via the app's resource bundle.
 * Usage: `Localizable("nav_chat").asString()`
 */
@Composable
fun Localizable(key: String): LocalizedString {
    val context = LocalContext.current
    val resId = context.resources.getIdentifier(key, "string", context.packageName)
    return LocalizedString(
        text = if (resId != 0) context.getString(resId) else key
    )
}

@JvmInline
value class LocalizedString(val text: String) {
    fun asString(): String = text
}
