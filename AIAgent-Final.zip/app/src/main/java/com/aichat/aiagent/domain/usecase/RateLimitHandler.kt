package com.aichat.aiagent.domain.usecase

import kotlinx.coroutines.delay
import javax.inject.Inject
import javax.inject.Singleton

enum class RateLimitAction {
    RETRY_10S, RETRY_30S, RETRY_60S, FALLBACK
}

@Singleton
class RateLimitHandler @Inject constructor() {

    private var attemptCount = 0

    fun getNextAction(): RateLimitAction {
        attemptCount++
        return when {
            attemptCount == 1 -> RateLimitAction.RETRY_10S
            attemptCount == 2 -> RateLimitAction.RETRY_30S
            attemptCount == 3 -> RateLimitAction.RETRY_60S
            else -> {
                reset()
                RateLimitAction.FALLBACK
            }
        }
    }

    suspend fun waitForAction(action: RateLimitAction) {
        when (action) {
            RateLimitAction.RETRY_10S -> delay(10_000)
            RateLimitAction.RETRY_30S -> delay(30_000)
            RateLimitAction.RETRY_60S -> delay(60_000)
            RateLimitAction.FALLBACK -> delay(1_000)
        }
    }

    fun reset() {
        attemptCount = 0
    }

    fun currentAttempt(): Int = attemptCount

    /**
     * Heuristic: a 429 status code or a "rate limit" substring in the error
     * indicates a real rate-limit error worth retrying. Other errors should
     * immediately fall back to the next provider.
     */
    fun isRateLimitError(error: Throwable?): Boolean {
        if (error == null) return false
        val message = error.message.orEmpty().lowercase()
        return message.contains("429") ||
            message.contains("rate limit") ||
            message.contains("too many requests") ||
            message.contains("quota exceeded")
    }
}
