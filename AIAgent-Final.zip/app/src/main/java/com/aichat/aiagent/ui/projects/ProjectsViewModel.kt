package com.aichat.aiagent.ui.projects

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.aichat.aiagent.data.local.database.dao.ProjectDao
import com.aichat.aiagent.data.local.database.entity.ProjectEntity
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

data class ProjectsUiState(
    val projects: List<ProjectEntity> = emptyList(),
    val isLoaded: Boolean = false
)

@HiltViewModel
class ProjectsViewModel @Inject constructor(
    private val projectDao: ProjectDao
) : ViewModel() {

    private val _state = MutableStateFlow(ProjectsUiState())
    val state: StateFlow<ProjectsUiState> = _state.asStateFlow()

    init {
        viewModelScope.launch {
            projectDao.observeAll().collect { projects ->
                _state.value = _state.value.copy(projects = projects, isLoaded = true)
            }
        }
    }

    fun createProject(name: String, description: String) {
        viewModelScope.launch {
            projectDao.insert(
                ProjectEntity(
                    name = name,
                    description = description
                )
            )
        }
    }

    fun deleteProject(project: ProjectEntity) {
        viewModelScope.launch {
            projectDao.deleteById(project.id)
        }
    }
}
