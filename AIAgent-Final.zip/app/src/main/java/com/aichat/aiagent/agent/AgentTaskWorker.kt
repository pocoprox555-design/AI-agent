package com.aichat.aiagent.agent

import android.content.Context
import androidx.hilt.work.HiltWorker
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.aichat.aiagent.AIAgentApplication
import com.aichat.aiagent.data.repository.ChatRepository
import com.aichat.aiagent.data.repository.ProviderRepository
import com.aichat.aiagent.domain.usecase.AutoRouter
import dagger.assisted.Assisted
import dagger.assisted.AssistedInject

@HiltWorker
class AgentTaskWorker @AssistedInject constructor(
    @Assisted appContext: Context,
    @Assisted params: WorkerParameters,
    private val chatRepository: ChatRepository,
    private val autoRouter: AutoRouter,
    private val providerRepository: ProviderRepository
) : CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result {
        val taskId = inputData.getString("task_id") ?: return Result.failure()
        val taskTitle = inputData.getString("task_title") ?: "AI Agent Task"

        return try {
            val sessionId = chatRepository.createSession(taskTitle)
            val enabledProviders = providerRepository.getAllPredefinedConfigs()
            val routing = autoRouter.route(taskTitle, enabledProviders)

            val result = chatRepository.sendMessage(
                sessionId = sessionId,
                content = "Execute task: $taskTitle",
                providerId = routing.providerId,
                modelId = routing.modelId
            )

            val responseText = result.getOrNull()?.content
                ?: "Task executed but no response content available"

            sendNotification(taskTitle, responseText.take(120))
            Result.success()
        } catch (e: Exception) {
            sendNotification(taskTitle, "Failed: ${e.message?.take(80)}")
            Result.retry()
        }
    }

    private fun sendNotification(title: String, content: String) {
        val notification = NotificationCompat.Builder(
            applicationContext,
            AIAgentApplication.NOTIFICATION_CHANNEL_ID
        )
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("AI Agent: $title")
            .setContentText(content)
            .setStyle(NotificationCompat.BigTextStyle().bigText(content))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .build()

        try {
            NotificationManagerCompat.from(applicationContext)
                .notify(title.hashCode(), notification)
        } catch (_: SecurityException) {
            // POST_NOTIFICATIONS not granted; ignore silently
        }
    }
}
