package com.aichat.aiagent.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

data class Particle(
    var x: Float,
    var y: Float,
    val speed: Float,
    val angle: Float,
    val size: Float,
    val alpha: Float,
    val color: Color
)

@Composable
fun ParticlesBackground(
    modifier: Modifier = Modifier,
    particleCount: Int = 30,
    lineColor: Color = Color(0x33FFFFFF),
    particleColors: List<Color> = listOf(
        Color(0x6600D4FF),
        Color(0x44FF00FF),
        Color(0x33FFFFFF)
    )
) {
    val infiniteTransition = rememberInfiniteTransition(label = "particles")
    val progress by infiniteTransition.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(
            tween(4000, easing = LinearEasing),
            RepeatMode.Restart
        ), label = "particleProgress"
    )

    val particles = remember(particleCount) {
        List(particleCount) {
            Particle(
                x = Random.nextFloat(),
                y = Random.nextFloat(),
                speed = 0.002f + Random.nextFloat() * 0.004f,
                angle = Random.nextFloat() * 360f,
                size = 1.5f + Random.nextFloat() * 3f,
                alpha = 0.3f + Random.nextFloat() * 0.5f,
                color = particleColors[Random.nextInt(particleColors.size)]
            )
        }
    }

    Canvas(modifier = modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height

        particles.forEachIndexed { index, particle ->
            val angleRad = Math.toRadians(particle.angle.toDouble() + progress * 360)
            particle.x += (cos(angleRad) * particle.speed).toFloat()
            particle.y += (sin(angleRad) * particle.speed).toFloat()

            if (particle.x < 0 || particle.x > 1) particle.x = Random.nextFloat()
            if (particle.y < 0 || particle.y > 1) particle.y = Random.nextFloat()

            val px = particle.x * w
            val py = particle.y * h

            drawCircle(
                color = particle.color.copy(alpha = particle.alpha),
                radius = particle.size,
                center = Offset(px, py)
            )

            particles.drop(index + 1).forEach { other ->
                val dx = (particle.x - other.x) * w
                val dy = (particle.y - other.y) * h
                val distance = kotlin.math.sqrt(dx * dx + dy * dy)
                if (distance < 120f) {
                    val lineAlpha = ((120f - distance) / 120f) * 0.15f
                    drawLine(
                        color = lineColor.copy(alpha = lineAlpha),
                        start = Offset(px, py),
                        end = Offset(other.x * w, other.y * h),
                        strokeWidth = 0.5f
                    )
                }
            }
        }
    }
}
