package com.aichat.aiagent.data.remote.api

import com.aichat.aiagent.util.EncryptionUtil
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ProviderFactory @Inject constructor(
    private val encryptionUtil: EncryptionUtil,
    private val okHttpClient: OkHttpClient
) {
    private val retrofitCache = mutableMapOf<String, Retrofit>()
    private val apiCache = mutableMapOf<String, Any>()

    fun getRetrofit(baseUrl: String): Retrofit {
        return retrofitCache.getOrPut(baseUrl) {
            Retrofit.Builder()
                .baseUrl(baseUrl)
                .client(okHttpClient)
                .addConverterFactory(GsonConverterFactory.create())
                .build()
        }
    }

    fun getOpenAIAPI(providerId: String): OpenAICompatibleAPI? {
        val config = getProviderConfig(providerId) ?: return null
        val apiKey = encryptionUtil.getApiKey(providerId)
        if (apiKey.isEmpty()) return null
        return getRetrofit(config.baseUrl).create(OpenAICompatibleAPI::class.java)
    }

    fun getGeminiAPI(): GeminiAPI {
        return apiCache.getOrPut("gemini") {
            getRetrofit("https://generativelanguage.googleapis.com/")
                .create(GeminiAPI::class.java)
        } as GeminiAPI
    }

    fun getHuggingFaceAPI(): HuggingFaceAPI {
        return apiCache.getOrPut("huggingface") {
            getRetrofit("https://api-inference.huggingface.co/")
                .create(HuggingFaceAPI::class.java)
        } as HuggingFaceAPI
    }

    fun getCohereAPI(): CohereAPI {
        return apiCache.getOrPut("cohere") {
            getRetrofit("https://api.cohere.ai/")
                .create(CohereAPI::class.java)
        } as CohereAPI
    }

    fun getCloudflareAPI(): CloudflareAPI {
        return apiCache.getOrPut("cloudflare") {
            getRetrofit("https://api.cloudflare.com/")
                .create(CloudflareAPI::class.java)
        } as CloudflareAPI
    }

    fun getNvidiaAPI(): NvidiaNIMAPI {
        return apiCache.getOrPut("nvidia") {
            getRetrofit("https://integrate.api.nvidia.com/")
                .create(NvidiaNIMAPI::class.java)
        } as NvidiaNIMAPI
    }

    fun getAnthropicAPI(): AnthropicAPI {
        return apiCache.getOrPut("anthropic") {
            getRetrofit("https://api.anthropic.com/")
                .create(AnthropicAPI::class.java)
        } as AnthropicAPI
    }

    fun getReplicateAPI(): ReplicateAPI {
        return apiCache.getOrPut("replicate") {
            getRetrofit("https://api.replicate.com/")
                .create(ReplicateAPI::class.java)
        } as ReplicateAPI
    }

    fun getDefaultModels(providerId: String): List<String> {
        return PredefinedProviders.all.find { it.id == providerId }?.defaultModels ?: emptyList()
    }

    fun getProviderConfig(providerId: String): ProviderConfig? {
        return PredefinedProviders.all.find { it.id == providerId }
    }

    fun getAllProviderConfigs(): List<ProviderConfig> = PredefinedProviders.all

    fun getEnabledProviders(): List<ProviderConfig> {
        return PredefinedProviders.all.filter { encryptionUtil.hasApiKey(it.id) }
    }

    fun getAuthorizationHeader(providerId: String): String {
        val apiKey = encryptionUtil.getApiKey(providerId)
        return "Bearer $apiKey"
    }
}
