package com.aichat.aiagent.ui.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.aichat.aiagent.data.local.datastore.UserPreferencesRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class SettingsViewModel @Inject constructor(
    private val repository: UserPreferencesRepository
) : ViewModel() {

    val preferences: StateFlow<com.aichat.aiagent.data.local.datastore.UserPreferences?> = repository.preferences
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    fun setDarkMode(enabled: Boolean) {
        viewModelScope.launch { repository.setDarkMode(enabled) }
    }

    fun setRtl(enabled: Boolean) {
        viewModelScope.launch { repository.setRtl(enabled) }
    }

    fun setAutoRouteEnabled(enabled: Boolean) {
        viewModelScope.launch { repository.setAutoRouteEnabled(enabled) }
    }

    fun setFontSizeScale(scale: Int) {
        viewModelScope.launch { repository.setFontSizeScale(scale) }
    }
}
