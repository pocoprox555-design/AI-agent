package com.aichat.aiagent.domain.usecase

import com.aichat.aiagent.data.remote.api.ProviderConfig
import com.aichat.aiagent.data.remote.api.ProviderFactory
import com.aichat.aiagent.domain.model.ModelCategory
import com.aichat.aiagent.util.EncryptionUtil
import javax.inject.Inject
import javax.inject.Singleton

data class RoutingDecision(
    val providerId: String,
    val modelId: String,
    val category: ModelCategory
)

@Singleton
class AutoRouter @Inject constructor(
    private val providerFactory: ProviderFactory,
    private val encryptionUtil: EncryptionUtil
) {
    fun route(userMessage: String, enabledProviders: List<ProviderConfig>): RoutingDecision {
        val category = classifyIntent(userMessage)

        val availableProviders = enabledProviders.filter {
            encryptionUtil.hasApiKey(it.id)
        }

        if (availableProviders.isEmpty()) {
            return RoutingDecision("groq", "llama3-8b-8192", ModelCategory.CHAT)
        }

        val priorityMap = mapOf(
            ModelCategory.CODE to listOf("groq", "cerebras", "deepinfra", "togetherai", "mistral"),
            ModelCategory.ANALYSIS to listOf("perplexity", "gemini", "openrouter", "cohere"),
            ModelCategory.IMAGE to listOf("stability", "replicate"),
            ModelCategory.CHAT to listOf("groq", "mistral", "openrouter", "gemini"),
            ModelCategory.EMBEDDING to listOf("cohere")
        )

        for (preferredId in priorityMap[category] ?: emptyList()) {
            val match = availableProviders.find { it.id == preferredId }
            if (match != null) {
                return RoutingDecision(match.id, match.defaultModels.firstOrNull() ?: "llama3-8b-8192", category)
            }
        }

        val fallback = availableProviders.first()
        return RoutingDecision(fallback.id, fallback.defaultModels.firstOrNull() ?: "llama3-8b-8192", category)
    }

    /**
     * Public test-friendly variant of intent classification (used by unit tests).
     */
    fun classifyIntentAdvanced(message: String): ModelCategory = classifyIntent(message)

    /**
     * Estimates a complexity score for a message. Higher = more complex.
     * Uses message length + keyword density as a heuristic.
     */
    fun estimateTaskComplexity(message: String): Int {
        if (message.isBlank()) return 0
        val lengthScore = message.length.coerceAtMost(500) / 10
        val complexKeywords = listOf(
            "implement", "design", "architecture", "distributed", "consensus",
            "byzantine", "fault tolerance", "optimize", "scale", "concurrent",
            "نظام موزّع", "خوارزمية", "تطبيق كامل", "تصميم معماري"
        )
        val lower = message.lowercase()
        val keywordScore = complexKeywords.count { lower.contains(it) } * 15
        return lengthScore + keywordScore
    }

    private fun classifyIntent(message: String): ModelCategory {
        val lower = message.lowercase()

        val imageScore = listOf("generate image", "create image", "draw", "صورة", "رسم", "تصميم", "stable diffusion")
            .count { lower.contains(it) }

        val codeScore = listOf("kotlin", "python", "java", "code", "function", "class", "implement",
            "debug", "fix", "compile", "api", "algorithm", "كود", "برمجة", "دالة", "خطأ")
            .count { lower.contains(it) }

        val analysisScore = listOf("analyze", "explain", "compare", "summarize", "what is", "how does",
            "why", "difference", "تحليل", "شرح", "قارن", "لخص", "ماهو", "كيف")
            .count { lower.contains(it) }

        return when {
            imageScore > codeScore && imageScore > analysisScore -> ModelCategory.IMAGE
            codeScore > analysisScore -> ModelCategory.CODE
            analysisScore > 0 -> ModelCategory.ANALYSIS
            else -> ModelCategory.CHAT
        }
    }
}
