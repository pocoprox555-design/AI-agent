package com.aichat.aiagent.ui.chat

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.aichat.aiagent.data.local.database.entity.ChatSessionEntity
import com.aichat.aiagent.data.remote.api.ProviderFactory
import com.aichat.aiagent.data.repository.ChatRepository
import com.aichat.aiagent.domain.model.ChatMessage
import com.aichat.aiagent.domain.model.ModelCategory
import com.aichat.aiagent.domain.usecase.AutoRouter
import com.aichat.aiagent.domain.usecase.RateLimitAction
import com.aichat.aiagent.domain.usecase.RateLimitHandler
import com.aichat.aiagent.util.TokenCounter
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import javax.inject.Inject

data class ChatUiState(
    val sessions: List<ChatSessionEntity> = emptyList(),
    val currentSessionId: Long = 0,
    val messages: List<ChatMessage> = emptyList(),
    val inputText: String = "",
    val isSending: Boolean = false,
    val isStreaming: Boolean = false,
    val streamedText: String = "",
    val selectedProvider: String = "",
    val selectedModel: String = "",
    val statusMessage: String = "",
    val statusType: StatusType = StatusType.IDLE,
    val error: String? = null
)

enum class StatusType {
    IDLE, THINKING, SEARCHING, TYPING, EXECUTING
}

@HiltViewModel
class ChatViewModel @Inject constructor(
    private val chatRepository: ChatRepository,
    private val autoRouter: AutoRouter,
    private val providerFactory: ProviderFactory,
    private val rateLimitHandler: RateLimitHandler
) : ViewModel() {

    private val _state = MutableStateFlow(ChatUiState())
    val state: StateFlow<ChatUiState> = _state.asStateFlow()

    private var streamingJob: Job? = null

    companion object {
        private const val MAX_CONTEXT_TOKENS = 4096
        private const val MAX_HISTORY_MESSAGES = 50
    }

    init {
        loadSessions()
    }

    private fun compressContext(messages: List<ChatMessage>, maxTokens: Int = MAX_CONTEXT_TOKENS): List<ChatMessage> {
        if (messages.size <= MAX_HISTORY_MESSAGES) {
            val totalTokens = messages.sumOf { TokenCounter.estimateTokens(it.content) }
            if (totalTokens <= maxTokens) return messages
        }
        val tail = messages.takeLast(MAX_HISTORY_MESSAGES)
        var budget = maxTokens
        val result = mutableListOf<ChatMessage>()
        for (msg in tail.reversed()) {
            val tokens = TokenCounter.estimateTokens(msg.content)
            if (budget - tokens <= 0 && result.isNotEmpty()) {
                result.add(msg.copy(content = TokenCounter.trimToMaxTokens(msg.content, budget)))
                break
            }
            if (budget - tokens > 0) {
                budget -= tokens
                result.add(msg)
            }
        }
        return result.reversed()
    }

    private fun loadSessions() {
        viewModelScope.launch {
            chatRepository.observeSessions().collectLatest { sessions ->
                _state.value = _state.value.copy(sessions = sessions)
                if (_state.value.currentSessionId == 0L && sessions.isNotEmpty()) {
                    selectSession(sessions.first().id)
                }
            }
        }
    }

    fun selectSession(sessionId: Long) {
        _state.value = _state.value.copy(currentSessionId = sessionId)
        viewModelScope.launch {
            chatRepository.observeMessagesAsDomain(sessionId).collectLatest { messages ->
                _state.value = _state.value.copy(messages = messages)
            }
        }
    }

    fun newSession() {
        viewModelScope.launch {
            val id = chatRepository.createSession()
            selectSession(id)
        }
    }

    fun updateInput(text: String) {
        _state.value = _state.value.copy(inputText = text)
    }

    fun sendMessage() {
        val text = _state.value.inputText.trim()
        if (text.isEmpty() || _state.value.isSending) return

        if (TokenCounter.containsSuspectedApiKey(text)) {
            _state.value = _state.value.copy(
                error = "Warning: Your message contains what looks like an API key. Removed for security.",
                inputText = ""
            )
            return
        }

        viewModelScope.launch {
            val sessionId = chatRepository.getOrCreateSession(_state.value.currentSessionId)
            if (_state.value.currentSessionId == 0L) {
                selectSession(sessionId)
            }

            val enabledProviders = providerFactory.getEnabledProviders()
            val routing = autoRouter.route(text, enabledProviders)

            _state.value = _state.value.copy(
                currentSessionId = sessionId,
                inputText = "",
                isSending = true,
                selectedProvider = routing.providerId,
                selectedModel = routing.modelId,
                statusMessage = when (routing.category) {
                    ModelCategory.CODE -> "Analyzing code..."
                    ModelCategory.ANALYSIS -> "Researching..."
                    ModelCategory.IMAGE -> "Generating image..."
                    ModelCategory.CHAT -> "Thinking..."
                    ModelCategory.EMBEDDING -> "Processing..."
                },
                statusType = StatusType.THINKING
            )

            val result = chatRepository.sendMessage(
                sessionId, text, routing.providerId, routing.modelId
            )

            result.fold(
                onSuccess = { msg ->
                    _state.value = _state.value.copy(
                        isSending = false,
                        statusType = StatusType.IDLE,
                        statusMessage = "",
                        error = null
                    )
                },
                onFailure = { error ->
                    _state.value = _state.value.copy(
                        isSending = false,
                        statusType = StatusType.IDLE,
                        statusMessage = "",
                        error = error.message
                    )
                }
            )
        }
    }

    fun sendMessageStreaming() {
        val text = _state.value.inputText.trim()
        if (text.isEmpty() || _state.value.isSending || _state.value.isStreaming) return

        if (TokenCounter.containsSuspectedApiKey(text)) {
            _state.value = _state.value.copy(
                error = "Warning: Your message contains what looks like an API key.",
                inputText = ""
            )
            return
        }

        streamingJob?.cancel()
        streamingJob = viewModelScope.launch {
            val sessionId = chatRepository.getOrCreateSession(_state.value.currentSessionId)
            if (_state.value.currentSessionId == 0L) selectSession(sessionId)

            val enabledProviders = providerFactory.getEnabledProviders()
            val routing = autoRouter.route(text, enabledProviders)
            rateLimitHandler.reset()

            _state.value = _state.value.copy(
                currentSessionId = sessionId,
                inputText = "",
                isStreaming = true,
                selectedProvider = routing.providerId,
                selectedModel = routing.modelId,
                statusType = StatusType.THINKING,
                statusMessage = "Thinking...",
                streamedText = ""
            )

            var currentProvider = routing.providerId
            var currentModel = routing.modelId
            var success = false

            while (!success) {
                val result = chatRepository.sendMessageStreaming(
                    sessionId, text, currentProvider, currentModel
                ) { token ->
                    _state.value = _state.value.copy(
                        streamedText = _state.value.streamedText + token,
                        statusType = StatusType.TYPING,
                        statusMessage = "Writing..."
                    )
                }

                result.fold(
                    onSuccess = { fullText ->
                        _state.value = _state.value.copy(
                            isStreaming = false,
                            statusType = StatusType.IDLE,
                            statusMessage = "",
                            streamedText = "",
                            error = null
                        )
                        success = true
                    },
                    onFailure = { err ->
                        // Only retry if it's a real rate limit error
                        if (!rateLimitHandler.isRateLimitError(err)) {
                            _state.value = _state.value.copy(
                                isStreaming = false,
                                statusType = StatusType.IDLE,
                                statusMessage = "",
                                error = err.message,
                                streamedText = ""
                            )
                            success = true
                            return@fold
                        }

                        val action = rateLimitHandler.getNextAction()
                        if (action == RateLimitAction.FALLBACK) {
                            val fallbackProviders = enabledProviders.filter { it.id != currentProvider }
                            if (fallbackProviders.isNotEmpty()) {
                                val fallback = fallbackProviders.first()
                                currentProvider = fallback.id
                                currentModel = fallback.defaultModels.firstOrNull() ?: "llama3-8b-8192"
                                _state.value = _state.value.copy(
                                    statusMessage = "Falling back to ${fallback.name}...",
                                    statusType = StatusType.SEARCHING
                                )
                                rateLimitHandler.reset()
                            } else {
                                _state.value = _state.value.copy(
                                    isStreaming = false,
                                    statusType = StatusType.IDLE,
                                    statusMessage = "",
                                    error = "All providers failed: ${err.message}",
                                    streamedText = ""
                                )
                                success = true
                            }
                        } else {
                            _state.value = _state.value.copy(
                                statusMessage = when (action) {
                                    RateLimitAction.RETRY_10S -> "Rate limited, retrying in 10s..."
                                    RateLimitAction.RETRY_30S -> "Rate limited, retrying in 30s..."
                                    RateLimitAction.RETRY_60S -> "Rate limited, retrying in 60s..."
                                    else -> "Retrying..."
                                },
                                statusType = StatusType.EXECUTING
                            )
                            rateLimitHandler.waitForAction(action)
                        }
                    }
                )
            }
        }
    }

    fun deleteSession(sessionId: Long) {
        viewModelScope.launch {
            chatRepository.deleteSession(sessionId)
            val sessions = _state.value.sessions
            val next = sessions.firstOrNull { it.id != sessionId }
            if (next != null) selectSession(next.id) else _state.value = _state.value.copy(currentSessionId = 0)
        }
    }

    fun cancelStreaming() {
        streamingJob?.cancel()
        streamingJob = null
        _state.value = _state.value.copy(
            isStreaming = false,
            statusType = StatusType.IDLE,
            statusMessage = "",
            streamedText = ""
        )
    }

    fun clearError() {
        _state.value = _state.value.copy(error = null)
    }
}
