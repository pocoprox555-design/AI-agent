package com.aichat.aiagent.agent

import android.content.Context
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.workDataOf
import dagger.hilt.android.qualifiers.ApplicationContext
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import javax.inject.Singleton

data class ScheduledTask(
    val id: String = "",
    val title: String,
    val description: String = "",
    val type: TaskType,
    val intervalHours: Long = 0,
    val triggerTime: Long = 0
)

enum class TaskType {
    ONE_TIME, REPEATING, EVENT_BASED
}

@Singleton
class TaskScheduler @Inject constructor(
    @param:ApplicationContext private val context: Context
) {
    private val workManager = WorkManager.getInstance(context)

    fun scheduleOneTimeTask(
        taskId: String,
        title: String,
        delaySeconds: Long
    ) {
        val workRequest = OneTimeWorkRequestBuilder<AgentTaskWorker>()
            .setInitialDelay(delaySeconds, TimeUnit.SECONDS)
            .setConstraints(
                Constraints.Builder()
                    .setRequiresBatteryNotLow(false)
                    .setRequiredNetworkType(androidx.work.NetworkType.CONNECTED)
                    .build()
            )
            .setInputData(
                workDataOf(
                    "task_id" to taskId,
                    "task_title" to title,
                    "task_type" to TaskType.ONE_TIME.name
                )
            )
            .addTag("task_$taskId")
            .build()

        workManager.enqueueUniqueWork(
            "one_time_$taskId",
            ExistingWorkPolicy.REPLACE,
            workRequest
        )
    }

    fun scheduleRepeatingTask(
        taskId: String,
        title: String,
        intervalHours: Long
    ) {
        // WorkManager enforces a minimum interval of 15 minutes for periodic work
        val intervalMinutes = (intervalHours * 60).coerceAtLeast(15L)
        val workRequest = PeriodicWorkRequestBuilder<AgentTaskWorker>(
            intervalMinutes, TimeUnit.MINUTES
        )
            .setConstraints(
                Constraints.Builder()
                    .setRequiredNetworkType(androidx.work.NetworkType.CONNECTED)
                    .build()
            )
            .setInputData(
                workDataOf(
                    "task_id" to taskId,
                    "task_title" to title,
                    "task_type" to TaskType.REPEATING.name
                )
            )
            .addTag("task_$taskId")
            .build()

        workManager.enqueueUniquePeriodicWork(
            "repeating_$taskId",
            ExistingPeriodicWorkPolicy.KEEP,
            workRequest
        )
    }

    fun scheduleEventBasedTask(taskId: String, title: String) {
        // Event-based tasks are simulated as one-time tasks triggered by app events.
        scheduleOneTimeTask(taskId, title, delaySeconds = 0)
    }

    fun cancelTask(taskId: String) {
        workManager.cancelUniqueWork("one_time_$taskId")
        workManager.cancelUniqueWork("repeating_$taskId")
        workManager.cancelAllWorkByTag("task_$taskId")
    }

    fun cancelAll() {
        workManager.cancelAllWork()
    }
}
