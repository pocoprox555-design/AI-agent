package com.aichat.aiagent.domain.model

data class ChatSession(
    val id: Long = 0,
    val title: String = "New Chat",
    val providerId: String = "",
    val modelId: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val messageCount: Int = 0,
    val isArchived: Boolean = false
)
