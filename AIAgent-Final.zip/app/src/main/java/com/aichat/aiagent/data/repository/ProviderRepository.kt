package com.aichat.aiagent.data.repository

import com.aichat.aiagent.data.local.database.dao.ProviderConfigDao
import com.aichat.aiagent.data.local.database.entity.ProviderConfigEntity
import com.aichat.aiagent.data.remote.api.ApiType
import com.aichat.aiagent.data.remote.api.PredefinedProviders
import com.aichat.aiagent.data.remote.api.ProviderConfig
import com.aichat.aiagent.data.remote.api.ProviderFactory
import com.aichat.aiagent.util.EncryptionUtil
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ProviderRepository @Inject constructor(
    private val providerConfigDao: ProviderConfigDao,
    private val providerFactory: ProviderFactory,
    private val encryptionUtil: EncryptionUtil,
    private val okHttpClient: OkHttpClient
) {
    fun observeAllProviders(): Flow<List<ProviderConfigEntity>> = providerConfigDao.observeAll()

    fun observeEnabledProviders(): Flow<List<ProviderConfigEntity>> = providerConfigDao.observeEnabled()

    suspend fun getProvider(id: String) = providerConfigDao.getById(id)

    suspend fun saveProvider(config: ProviderConfigEntity) = providerConfigDao.insert(config)

    suspend fun deleteProvider(config: ProviderConfigEntity) = providerConfigDao.delete(config)

    suspend fun saveApiKey(providerId: String, apiKey: String) {
        encryptionUtil.saveApiKey(providerId, apiKey)
        providerConfigDao.updateApiKey(providerId, apiKey)
    }

    fun getApiKey(providerId: String): String = encryptionUtil.getApiKey(providerId)

    suspend fun validateApiKey(providerId: String): ValidationResult {
        val config = providerFactory.getProviderConfig(providerId)
            ?: return ValidationResult(false, "Provider not found")
        val apiKey = encryptionUtil.getApiKey(providerId)
        if (apiKey.isEmpty()) return ValidationResult(false, "No API key saved")

        return withContext(Dispatchers.IO) {
            try {
                val response = when (config.apiType) {
                    ApiType.OPENAI_COMPATIBLE, ApiType.NVIDIA_NIM, ApiType.CLOUDFLARE, ApiType.REPLICATE -> {
                        validateOpenAICompatible(config.baseUrl, apiKey)
                    }
                    ApiType.GEMINI -> validateGemini(apiKey)
                    ApiType.HUGGINGFACE -> validateHuggingFace(apiKey)
                    ApiType.COHERE -> validateCohere(apiKey)
                    ApiType.ANTHROPIC -> validateAnthropic(apiKey)
                }

                if (response.success) {
                    if (response.models.isNotEmpty()) {
                        providerConfigDao.updateModels(providerId, response.models.joinToString(","))
                    }
                    ValidationResult(true, "Success! ${response.models.size} models found")
                } else {
                    ValidationResult(false, response.error ?: "Unknown error")
                }
            } catch (e: Exception) {
                ValidationResult(false, e.message ?: "Connection failed")
            }
        }
    }

    private data class ValidateResult(
        val success: Boolean,
        val models: List<String> = emptyList(),
        val error: String? = null
    )

    private fun validateOpenAICompatible(baseUrl: String, apiKey: String): ValidateResult {
        return try {
            val req = Request.Builder()
                .url("${baseUrl.trimEnd('/')}/v1/models")
                .addHeader("Authorization", "Bearer $apiKey")
                .get()
                .build()
            okHttpClient.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) {
                    return ValidateResult(false, error = "HTTP ${resp.code}: ${resp.body?.string()?.take(200)}")
                }
                val body = resp.body?.string() ?: return ValidateResult(false, error = "Empty response")
                val models = parseModelsResponse(body)
                ValidateResult(true, models = models)
            }
        } catch (e: Exception) {
            ValidateResult(false, error = e.message ?: "Network error")
        }
    }

    private fun validateGemini(apiKey: String): ValidateResult {
        return try {
            val req = Request.Builder()
                .url("https://generativelanguage.googleapis.com/v1beta/models?key=$apiKey")
                .get()
                .build()
            okHttpClient.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) {
                    return ValidateResult(false, error = "Gemini ${resp.code}")
                }
                val body = resp.body?.string() ?: return ValidateResult(false)
                val jsonObject = JSONObject(body)
                val arr = jsonObject.optJSONArray("models")
                val models = mutableListOf<String>()
                if (arr != null) {
                    for (i in 0 until arr.length()) {
                        val name = arr.getJSONObject(i).optString("name")
                        val cleaned = name.removePrefix("models/")
                        if (cleaned.isNotEmpty()) models.add(cleaned)
                    }
                }
                ValidateResult(true, models = models)
            }
        } catch (e: Exception) {
            ValidateResult(false, error = e.message)
        }
    }

    private fun validateHuggingFace(apiKey: String): ValidateResult {
        // HF doesn't expose a simple list endpoint; just check whoami-v2
        return try {
            val req = Request.Builder()
                .url("https://huggingface.co/api/whoami-v2")
                .addHeader("Authorization", "Bearer $apiKey")
                .get()
                .build()
            okHttpClient.newCall(req).execute().use { resp ->
                if (resp.isSuccessful) ValidateResult(true)
                else ValidateResult(false, error = "HF ${resp.code}")
            }
        } catch (e: Exception) {
            ValidateResult(false, error = e.message)
        }
    }

    private fun validateCohere(apiKey: String): ValidateResult {
        return try {
            val req = Request.Builder()
                .url("https://api.cohere.ai/v1/models")
                .addHeader("Authorization", "Bearer $apiKey")
                .get()
                .build()
            okHttpClient.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return ValidateResult(false, error = "Cohere ${resp.code}")
                val body = resp.body?.string() ?: return ValidateResult(false)
                val jsonObject = JSONObject(body)
                val arr = jsonObject.optJSONArray("models")
                val models = mutableListOf<String>()
                if (arr != null) {
                    for (i in 0 until arr.length()) {
                        val name = arr.getJSONObject(i).optString("name")
                        if (name.isNotEmpty()) models.add(name)
                    }
                }
                ValidateResult(true, models = models)
            }
        } catch (e: Exception) {
            ValidateResult(false, error = e.message)
        }
    }

    private fun validateAnthropic(apiKey: String): ValidateResult {
        // Anthropic has no list-models endpoint; send a tiny message to validate
        return try {
            val payload = JSONObject()
                .put("model", "claude-3-haiku-20240307")
                .put("max_tokens", 4)
                .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", "Hi")))
                .toString()
            val req = Request.Builder()
                .url("https://api.anthropic.com/v1/messages")
                .addHeader("x-api-key", apiKey)
                .addHeader("anthropic-version", "2023-06-01")
                .addHeader("Content-Type", "application/json")
                .post(payload.toRequestBody("application/json".toMediaType()))
                .build()
            okHttpClient.newCall(req).execute().use { resp ->
                if (resp.isSuccessful) ValidateResult(true)
                else ValidateResult(false, error = "Anthropic ${resp.code}")
            }
        } catch (e: Exception) {
            ValidateResult(false, error = e.message)
        }
    }

    suspend fun fetchModels(providerId: String): List<String> {
        val config = providerFactory.getProviderConfig(providerId) ?: return emptyList()
        val apiKey = encryptionUtil.getApiKey(providerId)
        if (apiKey.isEmpty()) return providerFactory.getDefaultModels(providerId)

        return withContext(Dispatchers.IO) {
            try {
                val req = Request.Builder()
                    .url("${config.baseUrl.trimEnd('/')}/v1/models")
                    .addHeader("Authorization", "Bearer $apiKey")
                    .get()
                    .build()
                okHttpClient.newCall(req).execute().use { resp ->
                    if (resp.isSuccessful) {
                        val models = parseModelsResponse(resp.body?.string() ?: "")
                        providerConfigDao.updateModels(providerId, models.joinToString(","))
                        models
                    } else {
                        providerFactory.getDefaultModels(providerId)
                    }
                }
            } catch (_: Exception) {
                providerFactory.getDefaultModels(providerId)
            }
        }
    }

    /**
     * Correctly parses OpenAI-style `{"data": [{"id": "..."}, ...]}` responses.
     * Falls back to plain JSON array `[{"id": "..."}, ...]` for other providers.
     */
    private fun parseModelsResponse(json: String): List<String> {
        val trimmed = json.trim()
        return try {
            // Try object form first (OpenAI-compatible standard)
            val jsonObject = JSONObject(trimmed)
            val dataArray = jsonObject.optJSONArray("data")
            if (dataArray != null) {
                val models = mutableListOf<String>()
                for (i in 0 until dataArray.length()) {
                    val obj = dataArray.optJSONObject(i)
                    val id = obj?.optString("id") ?: ""
                    if (id.isNotEmpty()) models.add(id)
                }
                return models
            }
            // If no "data" key, fall back to default models
            emptyList()
        } catch (_: Exception) {
            // Not an object, maybe a plain array
            try {
                val jsonArray = JSONArray(trimmed)
                val models = mutableListOf<String>()
                for (i in 0 until jsonArray.length()) {
                    val obj = jsonArray.optJSONObject(i)
                    val id = obj?.optString("id") ?: obj?.optString("name") ?: ""
                    if (id.isNotEmpty()) models.add(id)
                }
                models
            } catch (_: Exception) {
                emptyList()
            }
        }
    }

    suspend fun setProviderEnabled(providerId: String, enabled: Boolean) {
        providerConfigDao.setEnabled(providerId, enabled)
    }

    fun getAllPredefinedConfigs(): List<ProviderConfig> = providerFactory.getAllProviderConfigs()

    suspend fun initializeDefaultProviders() {
        providerFactory.getAllProviderConfigs().forEach { config ->
            val existingConfig = providerConfigDao.getById(config.id)
            if (existingConfig == null) {
                providerConfigDao.insert(
                    ProviderConfigEntity(
                        id = config.id,
                        name = config.name,
                        baseUrl = config.baseUrl,
                        apiKey = encryptionUtil.getApiKey(config.id),
                        isEnabled = encryptionUtil.hasApiKey(config.id),
                        models = config.defaultModels.joinToString(","),
                        priority = PredefinedProviders.all.indexOf(config)
                    )
                )
            }
        }
    }
}

data class ValidationResult(
    val success: Boolean,
    val message: String
)
