package com.aichat.aiagent.data.local.database.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "tasks")
data class TaskEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val description: String = "",
    val type: String = "ONE_TIME",
    val isActive: Boolean = true,
    val intervalHours: Long = 0,
    val createdAt: Long = System.currentTimeMillis(),
    val nextRunAt: String = ""
)
