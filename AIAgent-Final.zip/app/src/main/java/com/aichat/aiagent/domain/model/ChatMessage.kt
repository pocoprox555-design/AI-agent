package com.aichat.aiagent.domain.model

data class ChatMessage(
    val id: Long = 0,
    val sessionId: Long = 0,
    val role: MessageRole,
    val content: String,
    val timestamp: Long = System.currentTimeMillis(),
    val providerId: String = "",
    val modelId: String = "",
    val tokensUsed: Int = 0,
    val isStreaming: Boolean = false
)

enum class MessageRole {
    SYSTEM, USER, ASSISTANT
}
