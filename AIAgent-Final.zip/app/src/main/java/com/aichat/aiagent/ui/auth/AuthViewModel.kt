package com.aichat.aiagent.ui.auth

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.aichat.aiagent.util.EncryptionUtil
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.security.MessageDigest
import javax.inject.Inject

data class AuthUiState(
    val hasPin: Boolean = false,
    val isAuthenticated: Boolean = false,
    val isSetup: Boolean = false,
    val pinError: String? = null,
    val biometricAvailable: Boolean = false
)

@HiltViewModel
class AuthViewModel @Inject constructor(
    private val encryptionUtil: EncryptionUtil
) : ViewModel() {

    private val _state = MutableStateFlow(AuthUiState())
    val state: StateFlow<AuthUiState> = _state.asStateFlow()

    init {
        val hasPin = encryptionUtil.getString("app_pin_hash").isNotEmpty()
        _state.value = _state.value.copy(
            hasPin = hasPin,
            isAuthenticated = !hasPin,
            isSetup = !hasPin
        )
    }

    fun setPin(pin: String): Boolean {
        if (pin.length < 4) {
            _state.value = _state.value.copy(pinError = "PIN must be at least 4 digits")
            return false
        }
        val hash = pin.sha256()
        encryptionUtil.saveString("app_pin_hash", hash)
        _state.value = _state.value.copy(
            hasPin = true,
            isAuthenticated = true,
            isSetup = false,
            pinError = null
        )
        return true
    }

    fun verifyPin(pin: String): Boolean {
        val stored = encryptionUtil.getString("app_pin_hash")
        val valid = pin.sha256() == stored
        _state.value = _state.value.copy(
            isAuthenticated = valid,
            pinError = if (valid) null else "Wrong PIN"
        )
        return valid
    }

    fun setBiometricAvailable(available: Boolean) {
        _state.value = _state.value.copy(biometricAvailable = available)
    }

    fun onBiometricSuccess() {
        _state.value = _state.value.copy(isAuthenticated = true, pinError = null)
    }

    fun skipAuth() {
        val hasPin = encryptionUtil.getString("app_pin_hash").isNotEmpty()
        if (!hasPin) {
            _state.value = _state.value.copy(isAuthenticated = true)
        }
    }

    fun clearError() {
        _state.value = _state.value.copy(pinError = null)
    }

    private fun String.sha256(): String {
        val digest = MessageDigest.getInstance("SHA-256")
        return digest.digest(this.toByteArray()).joinToString("") { "%02x".format(it) }
    }
}
