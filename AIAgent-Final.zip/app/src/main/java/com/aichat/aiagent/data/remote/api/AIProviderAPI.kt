package com.aichat.aiagent.data.remote.api

import com.aichat.aiagent.data.remote.dto.ChatCompletionRequest
import com.aichat.aiagent.data.remote.dto.ChatCompletionResponse
import com.aichat.aiagent.data.remote.dto.CohereRequest
import com.aichat.aiagent.data.remote.dto.CohereResponse
import com.aichat.aiagent.data.remote.dto.GeminiRequest
import com.aichat.aiagent.data.remote.dto.GeminiResponse
import com.aichat.aiagent.data.remote.dto.HuggingFaceRequest
import com.aichat.aiagent.data.remote.dto.HuggingFaceResponse
import okhttp3.ResponseBody
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.POST
import retrofit2.http.Path
import retrofit2.http.Query

interface OpenAICompatibleAPI {
    @POST("v1/chat/completions")
    suspend fun chatCompletion(
        @Header("Authorization") auth: String,
        @Body request: ChatCompletionRequest
    ): Response<ChatCompletionResponse>

    @POST("v1/chat/completions")
    suspend fun chatCompletionStream(
        @Header("Authorization") auth: String,
        @Body request: ChatCompletionRequest
    ): Response<ResponseBody>

    @GET("v1/models")
    suspend fun listModels(
        @Header("Authorization") auth: String
    ): Response<ResponseBody>
}

interface GeminiAPI {
    @POST("v1beta/models/{model}:generateContent")
    suspend fun generateContent(
        @Path("model") model: String,
        @Query("key") apiKey: String,
        @Body request: GeminiRequest
    ): Response<GeminiResponse>
}

interface HuggingFaceAPI {
    @POST
    suspend fun generate(
        @Header("Authorization") auth: String,
        @Body request: HuggingFaceRequest
    ): Response<HuggingFaceResponse>
}

interface CohereAPI {
    @POST("v1/chat")
    suspend fun chat(
        @Header("Authorization") auth: String,
        @Body request: CohereRequest
    ): Response<CohereResponse>
}

interface CloudflareAPI {
    @POST("client/v4/accounts/{accountId}/ai/run/{model}")
    suspend fun run(
        @Header("Authorization") auth: String,
        @Path("accountId") accountId: String,
        @Path("model") model: String,
        @Body request: Map<String, Any>
    ): Response<ResponseBody>
}

interface NvidiaNIMAPI {
    @POST("v1/chat/completions")
    suspend fun chatCompletion(
        @Header("Authorization") auth: String,
        @Header("NVCF_PUB_KEY") pubKey: String?,
        @Body request: ChatCompletionRequest
    ): Response<ChatCompletionResponse>
}

interface AnthropicAPI {
    @POST("v1/messages")
    suspend fun sendMessage(
        @Header("x-api-key") apiKey: String,
        @Header("anthropic-version") version: String,
        @Body request: Map<String, Any>
    ): Response<ResponseBody>
}

interface ReplicateAPI {
    @POST("v1/predictions")
    suspend fun createPrediction(
        @Header("Authorization") auth: String,
        @Body request: Map<String, Any>
    ): Response<ResponseBody>

    @GET("v1/predictions/{id}")
    suspend fun getPrediction(
        @Header("Authorization") auth: String,
        @Path("id") id: String
    ): Response<ResponseBody>
}
