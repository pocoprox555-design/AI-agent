package com.aichat.aiagent.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aichat.aiagent.agent.DiffResult
import com.aichat.aiagent.ui.theme.ErrorRed
import com.aichat.aiagent.ui.theme.SuccessGreen

@Composable
fun DiffView(
    diffResult: DiffResult,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
            .padding(8.dp)
    ) {
        val scrollState = rememberScrollState()
        Column(modifier = Modifier.horizontalScroll(scrollState).widthIn(min = 200.dp)) {
            val maxLines = maxOf(diffResult.originalLines.size, diffResult.modifiedLines.size)
            for (i in 0 until maxLines) {
                val orig = diffResult.originalLines.getOrNull(i) ?: ""
                val mod = diffResult.modifiedLines.getOrNull(i) ?: ""
                val isAdded = i in diffResult.additions && orig.isEmpty()
                val isDeleted = i in diffResult.deletions && mod.isEmpty()
                val isModified = i in diffResult.additions && i in diffResult.deletions

                val bgColor = when {
                    isAdded || (isModified && mod.isNotEmpty()) -> SuccessGreen.copy(alpha = 0.15f)
                    isDeleted || (isModified && orig.isNotEmpty()) -> ErrorRed.copy(alpha = 0.15f)
                    else -> androidx.compose.ui.graphics.Color.Transparent
                }

                val prefix = when {
                    isAdded -> "+"
                    isDeleted -> "-"
                    isModified -> "±"
                    else -> " "
                }

                val prefixColor = when {
                    isAdded || (isModified && mod.isNotEmpty()) -> SuccessGreen
                    isDeleted || (isModified && orig.isNotEmpty()) -> ErrorRed
                    else -> MaterialTheme.colorScheme.onSurfaceVariant
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(bgColor)
                        .padding(horizontal = 4.dp, vertical = 1.dp)
                ) {
                    Text(
                        text = "${i + 1}".padStart(4) + " ",
                        style = MaterialTheme.typography.bodySmall,
                        fontFamily = FontFamily.Monospace,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                        fontSize = 12.sp
                    )
                    Text(
                        text = "$prefix ",
                        style = MaterialTheme.typography.bodySmall,
                        fontFamily = FontFamily.Monospace,
                        color = prefixColor,
                        fontSize = 12.sp
                    )
                    Text(
                        text = mod.ifNotEmpty() ?: orig,
                        style = MaterialTheme.typography.bodySmall,
                        fontFamily = FontFamily.Monospace,
                        color = MaterialTheme.colorScheme.onSurface,
                        fontSize = 12.sp
                    )
                }
            }
        }
    }
}

private fun String.ifNotEmpty(): String? = if (isEmpty()) null else this
