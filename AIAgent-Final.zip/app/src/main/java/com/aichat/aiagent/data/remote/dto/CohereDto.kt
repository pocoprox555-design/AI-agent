package com.aichat.aiagent.data.remote.dto

import com.google.gson.annotations.SerializedName

data class CohereRequest(
    @SerializedName("model") val model: String,
    @SerializedName("message") val message: String,
    @SerializedName("chat_history") val chatHistory: List<CohereMessage>? = null,
    @SerializedName("stream") val stream: Boolean = false
)

data class CohereMessage(
    @SerializedName("role") val role: String,
    @SerializedName("message") val message: String
)

data class CohereResponse(
    @SerializedName("text") val text: String? = null,
    @SerializedName("generation_id") val generationId: String? = null
)
