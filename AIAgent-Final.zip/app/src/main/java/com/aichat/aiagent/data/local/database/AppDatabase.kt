package com.aichat.aiagent.data.local.database

import androidx.room.Database
import androidx.room.RoomDatabase
import com.aichat.aiagent.data.local.database.dao.ChatSessionDao
import com.aichat.aiagent.data.local.database.dao.MessageDao
import com.aichat.aiagent.data.local.database.dao.ProjectDao
import com.aichat.aiagent.data.local.database.dao.ProviderConfigDao
import com.aichat.aiagent.data.local.database.dao.TaskDao
import com.aichat.aiagent.data.local.database.entity.ChatSessionEntity
import com.aichat.aiagent.data.local.database.entity.MessageEntity
import com.aichat.aiagent.data.local.database.entity.ProjectEntity
import com.aichat.aiagent.data.local.database.entity.ProviderConfigEntity
import com.aichat.aiagent.data.local.database.entity.TaskEntity

@Database(
    entities = [
        ChatSessionEntity::class,
        MessageEntity::class,
        ProviderConfigEntity::class,
        TaskEntity::class,
        ProjectEntity::class
    ],
    version = 2,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun chatSessionDao(): ChatSessionDao
    abstract fun messageDao(): MessageDao
    abstract fun providerConfigDao(): ProviderConfigDao
    abstract fun taskDao(): TaskDao
    abstract fun projectDao(): ProjectDao
}
