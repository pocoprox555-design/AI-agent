package com.aichat.aiagent.util

object TokenCounter {

    fun estimateTokens(text: String): Int {
        return (text.length / 4) + 1
    }

    fun trimToMaxTokens(text: String, maxTokens: Int): String {
        val maxChars = maxTokens * 4
        return if (text.length > maxChars) {
            text.take(maxChars) + "\n\n[...truncated...]"
        } else {
            text
        }
    }

    fun containsSuspectedApiKey(text: String): Boolean {
        val patterns = listOf(
            Regex("sk-[a-zA-Z0-9]{20,}"),
            Regex("api[-_]?key[-_]?[=: ]+['\"]?[a-zA-Z0-9]{16,}"),
            Regex("hf_[a-zA-Z0-9]{20,}"),
            Regex("key-[a-zA-Z0-9]{20,}"),
            Regex("bearer\\s+[a-zA-Z0-9]{20,}", RegexOption.IGNORE_CASE),
            Regex("x-api-key:\\s*[a-zA-Z0-9]{20,}", RegexOption.IGNORE_CASE),
            Regex("Authorization:\\s*Bearer\\s+[a-zA-Z0-9]{20,}", RegexOption.IGNORE_CASE)
        )
        return patterns.any { it.containsMatchIn(text) }
    }
}
