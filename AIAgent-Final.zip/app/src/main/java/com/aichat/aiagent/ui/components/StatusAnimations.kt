package com.aichat.aiagent.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.aichat.aiagent.ui.theme.CyanNeon
import com.aichat.aiagent.ui.theme.MagentaNeon
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

@Composable
fun NeuralAnimation(
    modifier: Modifier = Modifier,
    sizeDp: Dp = 32.dp,
    color: Color = MagentaNeon
) {
    val infiniteTransition = rememberInfiniteTransition(label = "neural")
    val rotation by infiniteTransition.animateFloat(
        0f, 360f,
        infiniteRepeatable(tween(2000, easing = LinearEasing), RepeatMode.Restart),
        label = "neuralRotate"
    )
    val pulse by infiniteTransition.animateFloat(
        0.3f, 1f,
        infiniteRepeatable(tween(800, easing = LinearEasing), RepeatMode.Reverse),
        label = "neuralPulse"
    )

    Canvas(modifier = modifier.size(sizeDp)) {
        val center = Offset(size.width / 2, size.height / 2)
        val radius = size.minDimension / 2 - 4.dp.toPx()

        for (i in 0 until 3) {
            val angle = Math.toRadians((rotation + i * 120).toDouble())
            val dotX = center.x + cos(angle).toFloat() * radius
            val dotY = center.y + sin(angle).toFloat() * radius
            drawCircle(
                color = color.copy(alpha = pulse),
                radius = 4.dp.toPx() * pulse,
                center = Offset(dotX, dotY)
            )
            drawLine(
                color = color.copy(alpha = pulse * 0.4f),
                start = center,
                end = Offset(dotX, dotY),
                strokeWidth = 1.dp.toPx()
            )
        }
        drawCircle(color = color.copy(alpha = pulse * 0.6f), radius = 3.dp.toPx(), center = center)
    }
}

@Composable
fun RadarAnimation(
    modifier: Modifier = Modifier,
    sizeDp: Dp = 32.dp,
    color: Color = CyanNeon
) {
    val infiniteTransition = rememberInfiniteTransition(label = "radar")
    val sweep by infiniteTransition.animateFloat(
        0f, 360f,
        infiniteRepeatable(tween(1500, easing = LinearEasing), RepeatMode.Restart),
        label = "radarSweep"
    )
    val pulse by infiniteTransition.animateFloat(
        0.2f, 1f,
        infiniteRepeatable(tween(600, easing = LinearEasing), RepeatMode.Reverse),
        label = "radarPulse"
    )

    Canvas(modifier = modifier.size(sizeDp)) {
        val c = Offset(size.width / 2, size.height / 2)
        val r = size.minDimension / 2

        drawCircle(color = color.copy(alpha = 0.1f), radius = r)
        drawCircle(color = color.copy(alpha = 0.05f), radius = r * 0.7f)

        val angle = Math.toRadians(sweep.toDouble())
        val endX = c.x + cos(angle).toFloat() * r
        val endY = c.y + sin(angle).toFloat() * r
        drawLine(color = color.copy(alpha = pulse), start = c, end = Offset(endX, endY), strokeWidth = 1.5f)

        for (i in 0 until 4) {
            val dotAngle = Math.toRadians((sweep + i * 90 + 15 * pulse).toDouble())
            val dx = c.x + cos(dotAngle).toFloat() * r * (0.3f + pulse * 0.4f)
            val dy = c.y + sin(dotAngle).toFloat() * r * (0.3f + pulse * 0.4f)
            drawCircle(color = color.copy(alpha = pulse * 0.6f), radius = 2.dp.toPx(), center = Offset(dx, dy))
        }
    }
}

@Composable
fun ProgressDots(
    modifier: Modifier = Modifier,
    sizeDp: Dp = 24.dp,
    color: Color = CyanNeon
) {
    val infiniteTransition = rememberInfiniteTransition(label = "progress")
    val progress by infiniteTransition.animateFloat(
        0f, 1f,
        infiniteRepeatable(tween(800, easing = LinearEasing), RepeatMode.Reverse),
        label = "progressDots"
    )

    Canvas(modifier = modifier.size(sizeDp)) {
        val dotCount = 3
        val spacing = size.width / (dotCount + 1)
        for (i in 0 until dotCount) {
            val alpha = ((progress + i.toFloat() / dotCount) % 1f).coerceIn(0.2f, 1f)
            val x = spacing * (i + 1)
            drawCircle(
                color = color.copy(alpha = alpha),
                radius = 3.dp.toPx(),
                center = Offset(x, size.height / 2)
            )
        }
    }
}
