package com.aichat.aiagent.ui.tasks

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.aichat.aiagent.agent.TaskScheduler
import com.aichat.aiagent.agent.TaskType
import com.aichat.aiagent.data.local.database.dao.TaskDao
import com.aichat.aiagent.data.local.database.entity.TaskEntity
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

data class TasksUiState(
    val tasks: List<TaskEntity> = emptyList(),
    val isLoaded: Boolean = false
)

@HiltViewModel
class TasksViewModel @Inject constructor(
    private val taskDao: TaskDao,
    private val taskScheduler: TaskScheduler
) : ViewModel() {

    private val _state = MutableStateFlow(TasksUiState())
    val state: StateFlow<TasksUiState> = _state.asStateFlow()

    init {
        viewModelScope.launch {
            taskDao.observeAll().collect { tasks ->
                _state.value = _state.value.copy(tasks = tasks, isLoaded = true)
            }
        }
    }

    fun addTask(title: String, description: String, type: TaskType) {
        viewModelScope.launch {
            val id = System.currentTimeMillis()
            val entity = TaskEntity(
                title = title,
                description = description,
                type = type.name,
                isActive = true,
                nextRunAt = when (type) {
                    TaskType.REPEATING -> "Every 24h"
                    else -> "Once"
                }
            )
            val insertedId = taskDao.insert(entity)
            when (type) {
                TaskType.ONE_TIME -> taskScheduler.scheduleOneTimeTask(
                    taskId = insertedId.toString(),
                    title = title,
                    delaySeconds = 3600
                )
                TaskType.REPEATING -> taskScheduler.scheduleRepeatingTask(
                    taskId = insertedId.toString(),
                    title = title,
                    intervalHours = 24
                )
                TaskType.EVENT_BASED -> {}
            }
        }
    }

    fun deleteTask(task: TaskEntity) {
        viewModelScope.launch {
            taskScheduler.cancelTask(task.id.toString())
            taskDao.deleteById(task.id)
        }
    }
}
