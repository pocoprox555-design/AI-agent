package com.aichat.aiagent.data.repository

import com.aichat.aiagent.data.local.database.dao.ChatSessionDao
import com.aichat.aiagent.data.local.database.dao.MessageDao
import com.aichat.aiagent.data.local.database.entity.ChatSessionEntity
import com.aichat.aiagent.data.local.database.entity.MessageEntity
import com.aichat.aiagent.data.remote.api.ApiType
import com.aichat.aiagent.data.remote.api.ProviderFactory
import com.aichat.aiagent.data.remote.dto.ChatCompletionRequest
import com.aichat.aiagent.data.remote.dto.GeminiContent
import com.aichat.aiagent.data.remote.dto.GeminiPart
import com.aichat.aiagent.data.remote.dto.GeminiRequest
import com.aichat.aiagent.data.remote.dto.MessageDto
import com.aichat.aiagent.domain.model.ChatMessage
import com.aichat.aiagent.domain.model.MessageRole
import com.aichat.aiagent.util.EncryptionUtil
import com.aichat.aiagent.util.TokenCounter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import okhttp3.sse.EventSource
import okhttp3.sse.EventSourceListener
import okhttp3.sse.EventSources
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ChatRepository @Inject constructor(
    private val chatSessionDao: ChatSessionDao,
    private val messageDao: MessageDao,
    private val providerFactory: ProviderFactory,
    private val encryptionUtil: EncryptionUtil,
    private val okHttpClient: OkHttpClient
) {
    fun observeSessions(): Flow<List<ChatSessionEntity>> = chatSessionDao.observeAll()

    fun observeMessages(sessionId: Long): Flow<List<MessageEntity>> = messageDao.observeBySession(sessionId)

    fun observeMessagesAsDomain(sessionId: Long): Flow<List<ChatMessage>> {
        return messageDao.observeBySession(sessionId).map { entities ->
            entities.map { it.toDomain() }
        }
    }

    suspend fun createSession(title: String = "New Chat"): Long {
        val session = ChatSessionEntity(title = title)
        return chatSessionDao.insert(session)
    }

    suspend fun getOrCreateSession(sessionId: Long?): Long {
        if (sessionId != null && sessionId > 0) return sessionId
        return createSession()
    }

    suspend fun saveMessage(
        sessionId: Long,
        role: MessageRole,
        content: String,
        providerId: String = "",
        modelId: String = ""
    ): ChatMessage {
        val entity = MessageEntity(
            sessionId = sessionId,
            role = role.name.lowercase(),
            content = content,
            providerId = providerId,
            modelId = modelId,
            tokensUsed = TokenCounter.estimateTokens(content)
        )
        val id = messageDao.insert(entity)
        chatSessionDao.getById(sessionId)?.let { existing ->
            chatSessionDao.update(existing.copy(updatedAt = System.currentTimeMillis()))
        }
        return entity.copy(id = id).toDomain()
    }

    suspend fun sendMessage(
        sessionId: Long,
        content: String,
        providerId: String,
        modelId: String
    ): Result<ChatMessage> {
        return withContext(Dispatchers.IO) {
            try {
                val apiKey = encryptionUtil.getApiKey(providerId)
                if (apiKey.isEmpty()) {
                    return@withContext Result.failure(Exception("No API key for $providerId"))
                }

                val config = providerFactory.getProviderConfig(providerId)
                    ?: return@withContext Result.failure(Exception("Provider $providerId not configured"))

                val messages = compressMessages(messageDao.getBySession(sessionId))
                val messageDtos = messages.map { msg ->
                    MessageDto(msg.role, msg.content)
                } + MessageDto("user", content)

                saveMessage(sessionId, MessageRole.USER, content, providerId, modelId)

                val reply = when (config.apiType) {
                    ApiType.OPENAI_COMPATIBLE -> callOpenAICompatible(
                        baseUrl = config.baseUrl,
                        apiKey = apiKey,
                        request = ChatCompletionRequest(modelId, messageDtos, stream = false)
                    )
                    ApiType.GEMINI -> callGemini(
                        apiKey = apiKey,
                        modelId = modelId,
                        messageDtos = messageDtos
                    )
                    ApiType.HUGGINGFACE -> callHuggingFace(
                        baseUrl = config.baseUrl,
                        modelId = modelId,
                        apiKey = apiKey,
                        messageDtos = messageDtos
                    )
                    ApiType.COHERE -> callCohere(
                        apiKey = apiKey,
                        modelId = modelId,
                        messageDtos = messageDtos
                    )
                    ApiType.ANTHROPIC -> callAnthropic(
                        apiKey = apiKey,
                        modelId = modelId,
                        messageDtos = messageDtos
                    )
                    ApiType.CLOUDFLARE, ApiType.NVIDIA_NIM, ApiType.REPLICATE ->
                        callOpenAICompatible(
                            baseUrl = config.baseUrl,
                            apiKey = apiKey,
                            request = ChatCompletionRequest(modelId, messageDtos, stream = false)
                        )
                }

                val assistantMsg = saveMessage(sessionId, MessageRole.ASSISTANT, reply, providerId, modelId)
                Result.success(assistantMsg)
            } catch (e: Exception) {
                Result.failure(e)
            }
        }
    }

    suspend fun sendMessageStreaming(
        sessionId: Long,
        content: String,
        providerId: String,
        modelId: String,
        onToken: (String) -> Unit
    ): Result<String> {
        return withContext(Dispatchers.IO) {
            try {
                val apiKey = encryptionUtil.getApiKey(providerId)
                if (apiKey.isEmpty()) {
                    return@withContext Result.failure(Exception("No API key for $providerId"))
                }

                saveMessage(sessionId, MessageRole.USER, content, providerId, modelId)

                val config = providerFactory.getProviderConfig(providerId)
                    ?: return@withContext Result.failure(Exception("Provider not configured"))

                val messages = compressMessages(messageDao.getBySession(sessionId))
                val messageDtos = messages.map { msg -> MessageDto(msg.role, msg.content) }

                val fullText = streamOpenAICompatible(
                    baseUrl = config.baseUrl,
                    apiKey = apiKey,
                    request = ChatCompletionRequest(modelId, messageDtos, stream = true),
                    onToken = onToken
                )

                saveMessage(sessionId, MessageRole.ASSISTANT, fullText, providerId, modelId)
                Result.success(fullText)
            } catch (e: Exception) {
                Result.failure(e)
            }
        }
    }

    private fun callOpenAICompatible(
        baseUrl: String,
        apiKey: String,
        request: ChatCompletionRequest
    ): String {
        val json = gsonToJson(request)
        val httpReq = Request.Builder()
            .url("${baseUrl.trimEnd('/')}/v1/chat/completions")
            .addHeader("Authorization", "Bearer $apiKey")
            .addHeader("Content-Type", "application/json")
            .post(json.toRequestBody("application/json".toMediaType()))
            .build()
        okHttpClient.newCall(httpReq).execute().use { resp ->
            if (!resp.isSuccessful) {
                val errBody = resp.body?.string() ?: ""
                throw Exception("API ${resp.code}: $errBody")
            }
            val body = resp.body?.string() ?: return ""
            val jsonObject = JSONObject(body)
            jsonObject.opt("error")?.let { errObj ->
                val msg = (errObj as? JSONObject)?.optString("message") ?: errObj.toString()
                throw Exception("API error: $msg")
            }
            val choices = jsonObject.optJSONArray("choices")
            if (choices != null && choices.length() > 0) {
                val first = choices.getJSONObject(0)
                val msg = first.optJSONObject("message")
                return msg?.optString("content") ?: first.optJSONObject("delta")?.optString("content") ?: ""
            }
            return body
        }
    }

    private fun callGemini(
        apiKey: String,
        modelId: String,
        messageDtos: List<MessageDto>
    ): String {
        val contents = messageDtos.map {
            GeminiContent(
                role = if (it.role == "assistant") "model" else "user",
                parts = listOf(GeminiPart(it.content))
            )
        }
        val request = GeminiRequest(contents = contents)
        val json = gsonToJson(request)
        val httpReq = Request.Builder()
            .url("https://generativelanguage.googleapis.com/v1beta/models/$modelId:generateContent?key=$apiKey")
            .post(json.toRequestBody("application/json".toMediaType()))
            .build()
        okHttpClient.newCall(httpReq).execute().use { resp ->
            if (!resp.isSuccessful) {
                throw Exception("Gemini ${resp.code}: ${resp.body?.string()}")
            }
            val body = resp.body?.string() ?: return ""
            val jsonObject = JSONObject(body)
            val candidates = jsonObject.optJSONArray("candidates")
            if (candidates != null && candidates.length() > 0) {
                val content = candidates.getJSONObject(0).optJSONObject("content")
                val parts = content?.optJSONArray("parts")
                if (parts != null && parts.length() > 0) {
                    return parts.getJSONObject(0).optString("text")
                }
            }
            return body
        }
    }

    private fun callHuggingFace(
        baseUrl: String,
        modelId: String,
        apiKey: String,
        messageDtos: List<MessageDto>
    ): String {
        val prompt = messageDtos.joinToString("\n") { "${it.role}: ${it.content}" }
        val payload = JSONObject().apply {
            put("inputs", prompt)
            put("parameters", JSONObject().apply {
                put("max_new_tokens", 1024)
                put("temperature", 0.7)
            })
        }
        val httpReq = Request.Builder()
            .url("${baseUrl.trimEnd('/')}/models/$modelId")
            .addHeader("Authorization", "Bearer $apiKey")
            .post(payload.toString().toRequestBody("application/json".toMediaType()))
            .build()
        okHttpClient.newCall(httpReq).execute().use { resp ->
            if (!resp.isSuccessful) {
                throw Exception("HF ${resp.code}: ${resp.body?.string()}")
            }
            val body = resp.body?.string() ?: return ""
            val arr = JSONArray(body)
            return if (arr.length() > 0) {
                arr.getJSONObject(0).optString("generated_text")
            } else body
        }
    }

    private fun callCohere(
        apiKey: String,
        modelId: String,
        messageDtos: List<MessageDto>
    ): String {
        val lastUser = messageDtos.lastOrNull { it.role == "user" }?.content ?: ""
        val history = messageDtos.dropLast(1).map {
            JSONObject().apply {
                put("role", it.role)
                put("message", it.content)
            }
        }
        val payload = JSONObject().apply {
            put("model", modelId)
            put("message", lastUser)
            put("chat_history", JSONArray(history))
        }
        val httpReq = Request.Builder()
            .url("https://api.cohere.ai/v1/chat")
            .addHeader("Authorization", "Bearer $apiKey")
            .post(payload.toString().toRequestBody("application/json".toMediaType()))
            .build()
        okHttpClient.newCall(httpReq).execute().use { resp ->
            if (!resp.isSuccessful) {
                throw Exception("Cohere ${resp.code}: ${resp.body?.string()}")
            }
            val body = resp.body?.string() ?: return ""
            return JSONObject(body).optString("text")
        }
    }

    private fun callAnthropic(
        apiKey: String,
        modelId: String,
        messageDtos: List<MessageDto>
    ): String {
        val systemMsg = messageDtos.firstOrNull { it.role == "system" }?.content ?: ""
        val userMessages = messageDtos.filter { it.role != "system" }.map {
            JSONObject().apply {
                put("role", it.role)
                put("content", it.content)
            }
        }
        val payload = JSONObject().apply {
            put("model", modelId)
            put("max_tokens", 2048)
            if (systemMsg.isNotEmpty()) put("system", systemMsg)
            put("messages", JSONArray(userMessages))
        }
        val httpReq = Request.Builder()
            .url("https://api.anthropic.com/v1/messages")
            .addHeader("x-api-key", apiKey)
            .addHeader("anthropic-version", "2023-06-01")
            .addHeader("Content-Type", "application/json")
            .post(payload.toString().toRequestBody("application/json".toMediaType()))
            .build()
        okHttpClient.newCall(httpReq).execute().use { resp ->
            if (!resp.isSuccessful) {
                throw Exception("Anthropic ${resp.code}: ${resp.body?.string()}")
            }
            val body = resp.body?.string() ?: return ""
            val jsonObject = JSONObject(body)
            val content = jsonObject.optJSONArray("content")
            return if (content != null && content.length() > 0) {
                content.getJSONObject(0).optString("text")
            } else body
        }
    }

    /**
     * Uses OkHttp's official SSE EventSource for proper streaming.
     * Falls back to non-streaming if no chunks arrive within 2 minutes.
     */
    private fun streamOpenAICompatible(
        baseUrl: String,
        apiKey: String,
        request: ChatCompletionRequest,
        onToken: (String) -> Unit
    ): String {
        val json = gsonToJson(request)
        val httpReq = Request.Builder()
            .url("${baseUrl.trimEnd('/')}/v1/chat/completions")
            .addHeader("Authorization", "Bearer $apiKey")
            .addHeader("Content-Type", "application/json")
            .addHeader("Accept", "text/event-stream")
            .post(json.toRequestBody("application/json".toMediaType()))
            .build()

        val factory = EventSources.createFactory(okHttpClient)
        val fullText = StringBuilder()
        val done = java.util.concurrent.CountDownLatch(1)
        var error: Exception? = null

        val es: EventSource = factory.newEventSource(httpReq, object : EventSourceListener() {
            override fun onEvent(eventSource: EventSource, id: String?, type: String?, data: String) {
                if (data == "[DONE]") {
                    eventSource.cancel()
                    return
                }
                try {
                    val jsonObject = JSONObject(data)
                    val choices = jsonObject.optJSONArray("choices")
                    if (choices != null && choices.length() > 0) {
                        val delta = choices.getJSONObject(0).optJSONObject("delta")
                        val text = delta?.optString("content") ?: ""
                        if (text.isNotEmpty()) {
                            fullText.append(text)
                            onToken(text)
                        }
                    }
                } catch (_: Exception) { /* ignore parse errors per chunk */ }
            }

            override fun onClosed(eventSource: EventSource) {
                done.countDown()
            }

            override fun onFailure(eventSource: EventSource, t: Throwable?, response: Response?) {
                error = if (t is Exception) t else Exception(t ?: RuntimeException("SSE failure"))
                done.countDown()
            }
        })

        done.await(2, TimeUnit.MINUTES)
        es.cancel()

        error?.let { throw it }

        // Fallback: if no chunks were received, attempt a non-streaming request
        if (fullText.isEmpty()) {
            return callOpenAICompatible(baseUrl, apiKey, request.copy(stream = false))
        }
        return fullText.toString()
    }

    suspend fun deleteSession(sessionId: Long) {
        chatSessionDao.archive(sessionId)
    }

    suspend fun deleteMessage(messageId: Long) {
        messageDao.deleteByMessageId(messageId)
    }

    private fun compressMessages(messages: List<MessageEntity>, maxTokens: Int = 4096): List<MessageEntity> {
        val totalTokens = messages.sumOf { TokenCounter.estimateTokens(it.content) }
        if (totalTokens <= maxTokens) return messages
        val maxHistory = 50
        val tail = messages.takeLast(maxHistory)
        var budget = maxTokens
        val result = mutableListOf<MessageEntity>()
        for (msg in tail.reversed()) {
            val tokens = TokenCounter.estimateTokens(msg.content)
            if (budget - tokens <= 0 && result.isNotEmpty()) {
                val truncated = msg.copy(content = TokenCounter.trimToMaxTokens(msg.content, budget))
                result.add(truncated)
                break
            }
            if (budget - tokens > 0) {
                budget -= tokens
                result.add(msg)
            }
        }
        return result.reversed()
    }

    private fun MessageEntity.toDomain() = ChatMessage(
        id = id, sessionId = sessionId,
        role = try { MessageRole.valueOf(role.uppercase()) } catch (_: Exception) { MessageRole.USER },
        content = content, timestamp = timestamp,
        providerId = providerId, modelId = modelId,
        tokensUsed = tokensUsed
    )

    private fun gsonToJson(obj: Any): String =
        com.google.gson.GsonBuilder().create().toJson(obj)
}
