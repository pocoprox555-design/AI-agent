package com.aichat.aiagent.data.remote.dto

import com.google.gson.annotations.SerializedName

data class HuggingFaceRequest(
    @SerializedName("inputs") val inputs: String,
    @SerializedName("parameters") val parameters: Map<String, Any> = emptyMap()
)

data class HuggingFaceResponse(
    @SerializedName("generated_text") val generatedText: String? = null,
    @SerializedName("error") val error: String? = null
)
