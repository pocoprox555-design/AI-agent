package com.aichat.aiagent.data.local.database.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "provider_configs")
data class ProviderConfigEntity(
    @PrimaryKey
    val id: String,
    val name: String,
    val baseUrl: String,
    val apiKey: String = "",
    val isEnabled: Boolean = true,
    val models: String = "",
    val priority: Int = 0,
    val lastUsed: Long = 0L
)
