package com.aichat.aiagent.agent

import android.content.Context
import android.net.Uri
import java.io.BufferedReader
import java.io.InputStreamReader
import javax.inject.Inject
import javax.inject.Singleton

data class FileContent(
    val fileName: String,
    val content: String,
    val mimeType: String,
    val lines: List<String>
)

data class DiffResult(
    val originalLines: List<String>,
    val modifiedLines: List<String>,
    val additions: List<Int>,
    val deletions: List<Int>
)

@Singleton
class FileProcessor @Inject constructor(
    private val context: Context
) {
    fun readFile(uri: Uri): FileContent? {
        return try {
            val mimeType = context.contentResolver.getType(uri) ?: "text/plain"
            val fileName = uri.lastPathSegment ?: "unknown"
            val content = when {
                isPdfFile(fileName) -> readPdf(uri) ?: readTextFallback(uri)
                isExcelFile(fileName) -> readExcel(uri) ?: readTextFallback(uri)
                else -> readTextFallback(uri)
            } ?: return null
            val lines = content.lines()
            FileContent(fileName, content, mimeType, lines)
        } catch (e: Exception) {
            null
        }
    }

    private fun readTextFallback(uri: Uri): String? {
        return try {
            val inputStream = context.contentResolver.openInputStream(uri) ?: return null
            val reader = BufferedReader(InputStreamReader(inputStream))
            val content = reader.readText()
            inputStream.close()
            content
        } catch (e: Exception) {
            null
        }
    }

    private fun readPdf(uri: Uri): String? {
        return try {
            val inputStream = context.contentResolver.openInputStream(uri) ?: return null
            val reader = com.itextpdf.kernel.pdf.PdfDocument(
                com.itextpdf.kernel.pdf.PdfReader(inputStream)
            )
            val text = StringBuilder()
            for (i in 1..reader.numberOfPages) {
                val page = reader.getPage(i)
                val strategy = com.itextpdf.kernel.pdf.canvas.parser.listener.SimpleTextExtractionStrategy()
                text.append(com.itextpdf.kernel.pdf.canvas.parser.PdfTextExtractor.getTextFromPage(page, strategy))
                text.append("\n")
            }
            reader.close()
            text.toString()
        } catch (e: Exception) {
            null
        }
    }

    private fun readExcel(uri: Uri): String? {
        return try {
            val inputStream = context.contentResolver.openInputStream(uri) ?: return null
            val workbook = when {
                uri.toString().endsWith(".xlsx") ->
                    org.apache.poi.xssf.usermodel.XSSFWorkbook(inputStream)
                else ->
                    org.apache.poi.hssf.usermodel.HSSFWorkbook(inputStream)
            }
            val text = StringBuilder()
            for (i in 0 until workbook.numberOfSheets) {
                val sheet = workbook.getSheetAt(i)
                text.appendLine("=== Sheet: ${sheet.sheetName} ===")
                for (row in sheet) {
                    val cells = mutableListOf<String>()
                    for (cell in row) {
                        cells.add(cell.toString())
                    }
                    text.appendLine(cells.joinToString("\t"))
                }
                text.appendLine()
            }
            workbook.close()
            inputStream.close()
            text.toString()
        } catch (e: Exception) {
            null
        }
    }

    fun computeDiff(original: FileContent, modified: String): DiffResult {
        val originalLines = original.lines
        val modifiedLines = modified.lines()
        val additions = mutableListOf<Int>()
        val deletions = mutableListOf<Int>()

        val maxLines = maxOf(originalLines.size, modifiedLines.size)
        for (i in 0 until maxLines) {
            val orig = originalLines.getOrNull(i) ?: ""
            val mod = modifiedLines.getOrNull(i) ?: ""
            if (orig != mod) {
                if (mod.isEmpty()) deletions.add(i)
                else if (orig.isEmpty()) additions.add(i)
                else {
                    additions.add(i)
                    deletions.add(i)
                }
            }
        }
        return DiffResult(originalLines, modifiedLines, additions, deletions)
    }

    fun getFileExtension(fileName: String): String {
        return fileName.substringAfterLast('.', "").lowercase()
    }

    fun isCodeFile(fileName: String): Boolean {
        return getFileExtension(fileName) in listOf(
            "kt", "java", "py", "js", "ts", "html", "css", "xml",
            "json", "yaml", "yml", "md", "txt", "gradle", "kts",
            "swift", "go", "rs", "cpp", "c", "h", "php", "rb"
        )
    }

    fun isExcelFile(fileName: String): Boolean {
        return getFileExtension(fileName) in listOf("xlsx", "xls")
    }

    fun isPdfFile(fileName: String): Boolean {
        return getFileExtension(fileName) == "pdf"
    }
}
