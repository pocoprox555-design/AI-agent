package com.aichat.aiagent.domain.model

data class AiModel(
    val id: String,
    val name: String,
    val providerId: String,
    val contextLength: Int = 4096,
    val isFree: Boolean = true,
    val supportsStreaming: Boolean = true,
    val supportsVision: Boolean = false,
    val supportsFunctions: Boolean = false,
    val category: ModelCategory = ModelCategory.CHAT
)

enum class ModelCategory {
    CHAT, CODE, ANALYSIS, IMAGE, EMBEDDING
}
