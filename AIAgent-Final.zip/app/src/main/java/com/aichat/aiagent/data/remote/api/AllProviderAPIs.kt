package com.aichat.aiagent.data.remote.api

import com.aichat.aiagent.data.remote.dto.ChatCompletionRequest
import com.aichat.aiagent.data.remote.dto.ChatCompletionResponse
import okhttp3.ResponseBody
import retrofit2.Response
import retrofit2.http.*

// ✅ 1. Groq API
interface GroqAPI {
    @POST("openai/v1/chat/completions")
    suspend fun chatCompletion(
        @Header("Authorization") auth: String,
        @Body request: ChatCompletionRequest
    ): Response<ChatCompletionResponse>

    @POST("openai/v1/chat/completions")
    suspend fun chatCompletionStream(
        @Header("Authorization") auth: String,
        @Body request: ChatCompletionRequest
    ): Response<ResponseBody>

    @GET("openai/v1/models")
    suspend fun listModels(
        @Header("Authorization") auth: String
    ): Response<ResponseBody>
}

// ✅ 2. SambaNova API
interface SambanovaAPI {
    @POST("api/v1/chat/completions")
    suspend fun chatCompletion(
        @Header("Authorization") auth: String,
        @Body request: ChatCompletionRequest
    ): Response<ChatCompletionResponse>

    @POST("api/v1/chat/completions")
    suspend fun chatCompletionStream(
        @Header("Authorization") auth: String,
        @Body request: ChatCompletionRequest
    ): Response<ResponseBody>
}

// ✅ 3. Cerebras API
interface CerebrasAPI {
    @POST("v1/chat/completions")
    suspend fun chatCompletion(
        @Header("Authorization") auth: String,
        @Body request: ChatCompletionRequest
    ): Response<ChatCompletionResponse>

    @POST("v1/chat/completions")
    suspend fun chatCompletionStream(
        @Header("Authorization") auth: String,
        @Body request: ChatCompletionRequest
    ): Response<ResponseBody>
}

// ✅ 4. Together AI API
interface TogetherAIAPI {
    @POST("v1/chat/completions")
    suspend fun chatCompletion(
        @Header("Authorization") auth: String,
        @Body request: ChatCompletionRequest
    ): Response<ChatCompletionResponse>

    @POST("v1/chat/completions")
    suspend fun chatCompletionStream(
        @Header("Authorization") auth: String,
        @Body request: ChatCompletionRequest
    ): Response<ResponseBody>
}

// ✅ 5. Mistral AI API
interface MistralAPI {
    @POST("v1/chat/completions")
    suspend fun chatCompletion(
        @Header("Authorization") auth: String,
        @Body request: ChatCompletionRequest
    ): Response<ChatCompletionResponse>

    @POST("v1/chat/completions")
    suspend fun chatCompletionStream(
        @Header("Authorization") auth: String,
        @Body request: ChatCompletionRequest
    ): Response<ResponseBody>
}

// ✅ 6. OpenRouter API
interface OpenRouterAPI {
    @POST("v1/chat/completions")
    suspend fun chatCompletion(
        @Header("Authorization") auth: String,
        @Body request: ChatCompletionRequest
    ): Response<ChatCompletionResponse>

    @POST("v1/chat/completions")
    suspend fun chatCompletionStream(
        @Header("Authorization") auth: String,
        @Body request: ChatCompletionRequest
    ): Response<ResponseBody>
}

// ✅ 7. Perplexity API
interface PerplexityAPI {
    @POST("chat/completions")
    suspend fun chatCompletion(
        @Header("Authorization") auth: String,
        @Body request: ChatCompletionRequest
    ): Response<ChatCompletionResponse>

    @POST("chat/completions")
    suspend fun chatCompletionStream(
        @Header("Authorization") auth: String,
        @Body request: ChatCompletionRequest
    ): Response<ResponseBody>
}

// ✅ 8. AI21 Labs API
interface AI21API {
    @POST("studio/v1/chat/completions")
    suspend fun chatCompletion(
        @Header("Authorization") auth: String,
        @Body request: ChatCompletionRequest
    ): Response<ChatCompletionResponse>

    @POST("studio/v1/chat/completions")
    suspend fun chatCompletionStream(
        @Header("Authorization") auth: String,
        @Body request: ChatCompletionRequest
    ): Response<ResponseBody>
}

// ✅ 9. Stability AI API
interface StabilityAPI {
    @POST("v1/generation/{engineId}/text-to-image")
    suspend fun generateImage(
        @Header("Authorization") auth: String,
        @Header("Content-Type") contentType: String = "application/json",
        @Path("engineId") engineId: String,
        @Body request: Map<String, Any>
    ): Response<ResponseBody>

    @POST("v1/chat/completions")
    suspend fun chatCompletion(
        @Header("Authorization") auth: String,
        @Body request: ChatCompletionRequest
    ): Response<ChatCompletionResponse>
}

// ✅ 10. Fireworks AI API
interface FireworksAPI {
    @POST("v1/chat/completions")
    suspend fun chatCompletion(
        @Header("Authorization") auth: String,
        @Body request: ChatCompletionRequest
    ): Response<ChatCompletionResponse>

    @POST("v1/chat/completions")
    suspend fun chatCompletionStream(
        @Header("Authorization") auth: String,
        @Body request: ChatCompletionRequest
    ): Response<ResponseBody>
}

// ✅ 11. DeepInfra API
interface DeepInfraAPI {
    @POST("v1/openai/chat/completions")
    suspend fun chatCompletion(
        @Header("Authorization") auth: String,
        @Body request: ChatCompletionRequest
    ): Response<ChatCompletionResponse>

    @POST("v1/openai/chat/completions")
    suspend fun chatCompletionStream(
        @Header("Authorization") auth: String,
        @Body request: ChatCompletionRequest
    ): Response<ResponseBody>
}
