package com.aichat.aiagent.ui.theme

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val Dark2050ColorScheme = darkColorScheme(
    primary = CyanNeon,
    onPrimary = DeepSpace,
    primaryContainer = CyanNeonDim,
    onPrimaryContainer = DarkOnSurface,
    secondary = MagentaNeon,
    onSecondary = DeepSpace,
    secondaryContainer = MagentaNeonDim,
    onSecondaryContainer = DarkOnSurface,
    tertiary = SuccessGreen,
    onTertiary = DeepSpace,
    background = DeepSpace,
    onBackground = DarkOnSurface,
    surface = DarkBlueSurface,
    onSurface = DarkOnSurface,
    surfaceVariant = DarkSurfaceVariant,
    onSurfaceVariant = DarkOnSurfaceVariant,
    error = ErrorRed,
    onError = DeepSpace,
    outline = GlassBorder
)

private val Light2050ColorScheme = lightColorScheme(
    primary = LightPrimary,
    onPrimary = LightSurface,
    primaryContainer = LightCard,
    onPrimaryContainer = LightPrimary,
    secondary = LightSecondary,
    onSecondary = LightSurface,
    secondaryContainer = LightCard,
    onSecondaryContainer = LightSecondary,
    tertiary = SuccessGreen,
    onTertiary = LightSurface,
    background = LightBackground,
    onBackground = LightOnSurface,
    surface = LightSurface,
    onSurface = LightOnSurface,
    surfaceVariant = LightCard,
    onSurfaceVariant = LightOnSurfaceVariant,
    error = ErrorRed,
    onError = LightSurface,
    outline = LightOnSurfaceVariant
)

@Composable
fun AIAgentTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    // Disabled by default so the 2050 Space Theme is always applied.
    // Material You overrides the neon palette and ruins the futuristic look.
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> Dark2050ColorScheme
        else -> Light2050ColorScheme
    }

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            if (window != null) {
                WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = !darkTheme
                window.statusBarColor = android.graphics.Color.TRANSPARENT
                window.navigationBarColor = android.graphics.Color.TRANSPARENT
            }
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
