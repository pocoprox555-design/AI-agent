package com.aichat.aiagent

import androidx.test.platform.app.InstrumentationRegistry
import androidx.test.ext.junit.runners.AndroidJUnit4
import org.junit.Test
import org.junit.runner.RunWith

/**
 * Instrumented test, which will execute on an Android device.
 * Verifies that the application context loads correctly.
 */
@RunWith(AndroidJUnit4::class)
class AppContextTest {

    @Test
    fun useAppContext() {
        val context = InstrumentationRegistry.getInstrumentation().targetContext
        assert(context.packageName == "com.aichat.aiagent")
    }
}
