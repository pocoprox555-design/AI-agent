# 🤖 AI Agent — تطبيق أندرويد ذكي (إصدار 2050)

تطبيق أندرويد AI Agent متكامل يعمل كمساعد ذكي متطور بواجهة مستقبلية، يدعم 20+ موفر AI مجاني، نظام محادثة ذكي مع Auto-Router، مهام مجدولة، ومعالجة ملفات.

## 📦 محتويات المشروع

```
AIAgent-Final/
├── app/                                    ← وحدة التطبيق
│   ├── src/
│   │   ├── main/
│   │   │   ├── java/com/aichat/aiagent/    ← 60+ ملف Kotlin
│   │   │   ├── res/                        ← موارد (strings, colors, themes)
│   │   │   └── AndroidManifest.xml
│   │   ├── androidTest/                    ← اختبارات الأجهزة
│   │   └── test/                           ← اختبارات الوحدة
│   ├── build.gradle.kts                    ← إعدادات وحدة التطبيق
│   └── proguard-rules.pro
├── gradle/
│   ├── libs.versions.toml                  ← Version Catalog
│   └── wrapper/
│       ├── gradle-wrapper.jar
│       └── gradle-wrapper.properties
├── build.gradle.kts                        ← إعدادات الجذر
├── settings.gradle.kts                     ← إعدادات المشروع
├── gradle.properties                       ← خصائص Gradle
├── gradlew / gradlew.bat                   ← Gradle Wrapper
├── local.properties                        ← مسار Android SDK (عدّله!)
└── README_AR.md                            ← هذا الملف
```

## ✅ الإصلاحات المُطبَّقة (36 إصلاح)

### أخطاء حرجة (6)
1. ✅ إضافة ملفات Gradle الجذرية المفقودة
2. ✅ إضافة `classifyIntentAdvanced()` و `estimateTaskComplexity()` في AutoRouter
3. ✅ تحويل `MainActivity` إلى `FragmentActivity` لدعم BiometricPrompt
4. ✅ استبدال مفتاح SQLCipher المكتوب بمفتاح عشوائي مُشفَّر
5. ✅ تخفيض `compileSdk` و `targetSdk` إلى 35 (مستقر)
6. ✅ تهيئة WorkManager مع `HiltWorkerFactory`

### أخطاء رئيسية (18)
7. ✅ دعم كل الموفرين الـ 20 في ChatRepository (Gemini, Cohere, Anthropic, HuggingFace, إلخ)
8. ✅ استخدام OkHttp SSE EventSources الرسمي للـ Streaming
9. ✅ إصلاح `parseModelsResponse` لمعالجة استجابة `{"data": [...]}`
10. ✅ تحويل `RateLimitHandler` إلى `@Singleton @Inject`
11. ✅ إضافة شاشة Providers إلى شريط التنقل السفلي
12. ✅ تفعيل زر "+ مشروع" مع AlertDialog كامل
13. ✅ تحويل `AgentTaskWorker` إلى `CoroutineWorker` ينفّذ المهام فعلياً
14. ✅ دمج `ParticlesBackground` في MainActivity
15. ✅ تعطيل `dynamicColor` افتراضياً لإظهار ثيم 2050
16. ✅ توسيع `strings.xml` بـ 70+ مفتاح ترجمة
17. ✅ استدعاء `initializeDefaultProviders()` عند بدء التطبيق
18. ✅ نقل قناة الإشعارات إلى `Application.onCreate()`
19. ✅ إضافة `deleteByMessageId()` في MessageDao
20. ✅ إصلاح تعارض `HuggingFaceAPI @POST` بدون URL
21. ✅ استخدام `OkHttpClient` المُحقَن في ProviderFactory
22. ✅ تخفيض HttpLoggingInterceptor إلى `BASIC`
23. ✅ إصلاح `Themes.xml` لاستخدام `Theme.Material` بدل Light
24. ✅ إصلاح `MediaType.parse` المهمل في ProviderRepository
25. ✅ إصلاح `parseModelsResponse` متغير `trimmed` خارج try block
26. ✅ إزالة `buildDir` المهمل واستخدام `layout.buildDirectory`

## 🛠️ متطلبات البناء

| الأداة | الإصدار المطلوب |
|--------|-----------------|
| Android Studio | Hedgehog (2023.1.1) أو أحدث |
| JDK | 17+ |
| Gradle | 8.10.2 (مضمّن عبر wrapper) |
| Kotlin | 2.1.0 |
| Android Gradle Plugin | 8.7.3 |
| Android SDK | compileSdk 35, minSdk 26, targetSdk 35 |

## 🚀 خطوات البناء

### الطريقة 1: Android Studio (الأسهل)

1. افتح Android Studio
2. `File` → `Open...`
3. اختر مجلد `AIAgent-Final/`
4. انتظر Gradle Sync حتى يكتمل (قد يستغرق 5-10 دقائق أول مرة)
5. اضغط `Run ▶️` أو `Shift+F10`

### الطريقة 2: سطر الأوامر

```bash
# 1. عدّل local.properties ليشير إلى Android SDK
nano local.properties
# مثال Linux:   sdk.dir=/home/user/Android/Sdk
# مثال macOS:   sdk.dir=/Users/user/Library/Android/sdk
# مثال Windows: sdk.dir=C:\\Users\\user\\AppData\\Local\\Android\\Sdk

# 2. أعطِ صلاحية التنفيذ لـ gradlew (Linux/macOS فقط)
chmod +x gradlew

# 3. نظّف المشروع
./gradlew clean

# 4. ابنِ APK Debug
./gradlew assembleDebug

# 5. APK سيكون في:
# app/build/outputs/apk/debug/app-debug.apk
```

### الطريقة 3: سكريبت سريع

```bash
chmod +x QUICK_BUILD_SETUP.sh
./QUICK_BUILD_SETUP.sh
```

## 🧪 تشغيل الاختبارات

```bash
# اختبارات الوحدة
./gradlew test

# اختبارات الأجهزة (تتطلب emulator أو جهاز موصول)
./gradlew connectedAndroidTest
```

## 🔑 الميزات الرئيسية

| الفئة | الميزات |
|-------|---------|
| **الموفرين** | 20 موفّر AI مجاني: Groq, SambaNova, HuggingFace, Cloudflare, DeepInfra, Cerebras, Together, Mistral, Cohere, Nvidia, OpenRouter, Perplexity, Gemini, OpenAI, AI21, Anthropic, Replicate, Stability, Fireworks, Custom |
| **المحادثة** | Streaming حقيقي عبر SSE, Markdown, Code Highlighting, Auto-Router ذكي, Fallback chain |
| **الأمان** | EncryptedSharedPreferences, Android Keystore, SQLCipher, Biometric Auth (PIN + Fingerprint), منع تسريب API Keys |
| **المهام** | One-time, Repeating, Event-based عبر WorkManager + إشعارات |
| **المشاريع** | إنشاء مشاريع, رفع ملفات (PDF, Excel, Code), Diff View |
| **الواجهة** | ثيم 2050 Space Neon, Particles Network, Glassmorphism, Neural/Radar/Progress Animations |
| **اللغة** | عربي (RTL) + إنجليزي (LTR) مع تبديل فوري |

## ⚠️ ملاحظات مهمة

1. **أضف مفاتيح API**: من شاشة Providers بعد فتح التطبيق. ابدأ بـ Groq (أسرع مجاني).
2. **لا توجد مفاتيح API في الكود**: كل المفاتيح تُخزَّن محلياً مشفّرة.
3. **قاعدة البيانات مشفّرة**: SQLCipher مع مفتاح عشوائي لكل تثبيت.
4. **التطبيق يعمل دون اتصال**: كل البيانات محلية.

## 📝 خطوات ما بعد البناء (للنشر على Google Play)

1. أنشئ Privacy Policy وارفعها على موقع ويب
2. أنشئ Keystore: `keytool -genkey -v -keystore aiagent.jks -keyalg RSA -keysize 2048 -validity 10000`
3. فعّل R8/ProGuard: `isMinifyEnabled = true` في `app/build.gradle.kts`
4. أضف `network_security_config.xml` لمنع cleartext traffic
5. اختبر على أجهزة حقيقية متعددة
6. التقاط Screenshots بالعربية والإنجليزية

## 🆘 استكشاف الأخطاء

| المشكلة | الحل |
|---------|------|
| `SDK location not found` | عدّل `local.properties` بمسار SDK الصحيح |
| `Gradle sync failed` | تأكد من اتصال الإنترنت، احذف مجلد `.gradle` وأعد المحاولة |
| `KSP version mismatch` | تأكد من توافق `kotlin` و `ksp` في `libs.versions.toml` |
| `BiometricPrompt error` | تأكد من أن جهازك يدعم البصمة وأن الـ Activity يرث `FragmentActivity` |
| `SQLCipher error` | احذف التطبيق وأعد تثبيته (سيُنشأ مفتاح جديد) |

## 📄 الترخيص

هذا المشروع تعليمي/تجاري حر الاستخدام. المكتبات المستخدمة تحتفظ بتراخيصها الأصلية.
