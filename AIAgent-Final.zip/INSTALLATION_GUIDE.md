# 🚀 دليل التثبيت والبناء

## المتطلبات الأساسية:

### 1. Android Studio
- **الإصدار الأخير** (2024.1 أو أحدث)
- تنزيل من: https://developer.android.com/studio

### 2. Android SDK
- **API Level 34+**
- **Android SDK Tools**
- **Emulator** (اختياري)

### 3. Java Development Kit
- **JDK 17 أو أحدث**
- OpenJDK أو Oracle JDK

---

## خطوات التثبيت:

### ✅ الخطوة 1: فتح المشروع
```bash
1. افتح Android Studio
2. انقر على "File" → "Open"
3. اختر مجلد: AIAgent-Build-Fixed
4. انقر "Open"
```

### ✅ الخطوة 2: انتظر تجميع Gradle
```
Android Studio سيقوم تلقائياً بـ:
- تنزيل Gradle 9.4.1
- تنزيل جميع التبعيات (38 مكتبة)
- فهرسة الملفات
- هذا قد يستغرق 5-10 دقائق في المرة الأولى
```

### ✅ الخطوة 3: اختر الجهاز
```bash
اختر أحد الخيارات:
1. Android Emulator (محاكي)
   - Device Manager → Create Device
2. جهاز حقيقي (متصل عبر USB)
   - تفعيل USB Debugging في الإعدادات
```

### ✅ الخطوة 4: البناء والتشغيل
```bash
انقر على: Run (Shift + F10)
أو اختر: Run → Run 'app'
```

---

## الأوامر البديلة (Terminal):

### بناء التطبيق:
```bash
cd AIAgent-Build-Fixed
./gradlew build
```

### تشغيل على emulator:
```bash
./gradlew installDebug
```

### بناء Release APK:
```bash
./gradlew assembleRelease
```

### بناء بدون اختبارات:
```bash
./gradlew build -x test
```

---

## حل المشاكل الشائعة:

### ❌ مشكلة: "SDK not found"
```bash
✅ الحل:
1. افتح: Tools → SDK Manager
2. اختر: SDK Platforms
3. ثبت: Android 14 (API 34)
4. اختر: SDK Tools → Android Gradle Plugin
```

### ❌ مشكلة: "Gradle build failed"
```bash
✅ الحل:
1. انقر: File → Invalidate Caches
2. اختر: Invalidate and Restart
3. انتظر إعادة التشغيل
```

### ❌ مشكلة: "Out of Memory"
```bash
✅ الحل:
1. افتح: gradle.properties
2. غيّر: org.gradle.jvmargs=-Xmx4096m
   إلى: org.gradle.jvmargs=-Xmx8192m
3. أعد تشغيل Gradle
```

### ❌ مشكلة: "Build cache is corrupted"
```bash
✅ الحل:
./gradlew build --no-build-cache
```

---

## معلومات الحزمة (APK):

- **اسم الحزمة**: com.aichat.aiagent
- **الإصدار**: 1.0.0
- **رقم البناء**: 1
- **الحد الأدنى لـ Android**: API 29
- **الهدف**: API 34

---

## الملفات المُنتجة:

### بعد البناء الناجح:
```
app/build/outputs/
├── apk/
│   ├── debug/app-debug.apk (للاختبار)
│   └── release/app-release.apk (للنشر)
└── bundle/
    └── release/app-release.aab (لـ Google Play)
```

---

## الخطوات التالية:

1. ✅ تثبيت التطبيق على الجهاز
2. ✅ اختبار جميع الميزات
3. ✅ إضافة API Keys لـ AI Providers
4. ✅ بدء استخدام التطبيق

---

## الدعم والمساعدة:

- **وثائق Android**: https://developer.android.com
- **Gradle Docs**: https://gradle.org
- **Kotlin Docs**: https://kotlinlang.org

---

**آخر تحديث**: 2026-06-25
**الحالة**: ✅ جاهز للبناء
